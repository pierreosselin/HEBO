import numpy as np
import tensorflow as tf
import torch
from matplotlib import pyplot as plt
from functools import reduce
from operator import __mul__
import transporter_orig
from transporter import KeyPointer, Encoder, Decoder, Transporter

norm_type = 'instance'
# norm_type = 'layer'
# norm_type = 'none'

convnet_encoder_kwargs = dict(
    filters=(16, 16, 32, 32),
    strides=(1, 1, 2, 1),
    kernel_sizes=(7, 3, 3, 3),
)
decoder_num_filters = 128

num_keypoints = 5
gauss_std = 0.1

image_shape = (128, 128)

tf.get_logger().setLevel('ERROR')
tf.reset_default_graph()
tf.set_random_seed(0)

encoder = transporter_orig.Encoder(
    name='encoder',
    norm_type=norm_type,
    **convnet_encoder_kwargs)
keypoint_encoder = transporter_orig.Encoder(
    name='keypoint_encoder',
    norm_type=norm_type,
    **convnet_encoder_kwargs)

decoder = transporter_orig.Decoder(
    initial_filters=decoder_num_filters,
    output_size=image_shape,
    norm_type=norm_type)

keypointer = transporter_orig.KeyPointer(
    num_keypoints=num_keypoints,
    gauss_std=gauss_std,
    keypoint_encoder=keypoint_encoder)

t1 = transporter_orig.Transporter(
    encoder=encoder,
    decoder=decoder,
    keypointer=keypointer)

image_a_pl = tf.placeholder(
    shape=(1, image_shape[0], image_shape[1], 3),
    dtype=tf.float32)

image_b_pl = tf.placeholder(
    shape=(1, image_shape[0], image_shape[1], 3),
    dtype=tf.float32)

outputs_tf = t1(image_a_pl, image_b_pl, is_training=False)

# not enough
torch.manual_seed(0)
# norm_type = 'layer'
# norm_type = 'instance'
device = torch.device("cpu")
height = 128
e = Encoder(height, norm_type=norm_type)
ek = Encoder(height, norm_type=norm_type)
inner_channel = 32
inner_height = 64
e.to(device)
ek.to(device)
d = Decoder(inner_channel, decoder_num_filters, inner_height, height, norm_type=norm_type)
d.to(device)
k = KeyPointer(5, ek, 0.1, initial_filters=inner_channel)
k.to(device)
t2 = Transporter(e, d, k)
t2.to(device)

(sources, targets) = torch.load('PongNoFrameskip-v4_post.pt')
sources = sources.float() / 255.
targets = targets.float() / 255.

batch_index = 1
sources = sources[batch_index:batch_index+1]
targets = targets[batch_index:batch_index+1]

t2 = t2.eval()

print(t2)

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())

    if norm_type != "none":
        encoder_layer_index_mapping = {1: 1, 2: 5, 3: 9, 4: 13}
        decoder_layer_index_mapping = {1: 1, 2: 5, 3: 10, 4: 14}
    else:
        encoder_layer_index_mapping = {1: 1, 2: 4, 3: 7, 4: 10}
        decoder_layer_index_mapping = {1: 1, 2: 4, 3: 8, 4: 11}
    for var_name in tf.trainable_variables():
        params_to_copy = sess.run(var_name)

        var_name = str(var_name)
        layer_label = var_name.split("'")[1].split("/")[1]
        layer_index = int(layer_label.split('_')[1])

        offset = 0
        if 'normalization' in var_name:
            offset = 1

        if 'key_pointer' in var_name and layer_index == 1:
            ptr = t2.keypointer.net
        elif 'keypoint_encoder' in var_name:
            ptr = t2.keypointer.keypoint_encoder.net[encoder_layer_index_mapping[layer_index]+offset]
        elif 'encoder' in var_name:
            ptr = t2.encoder.net[encoder_layer_index_mapping[layer_index]+offset]
        elif 'decoder' in var_name:
            ptr = t2.decoder.layers[decoder_layer_index_mapping[layer_index]+offset]

        if 'w:0' in var_name:
            ptr = ptr.weight
        elif 'b:0' in var_name:
            ptr = ptr.bias
        elif 'gamma:0' in var_name:
            ptr = ptr.weight
        elif 'beta:0' in var_name:
            ptr = ptr.bias

        print(var_name)
        if len(params_to_copy.shape) == 4:
            if ptr.data.shape != params_to_copy.transpose(3, 2, 1, 0).shape:
                breakpoint()
            ptr.data = torch.from_numpy(params_to_copy.transpose(3, 2, 1, 0)).float()
        else:
            if 'normalization' in var_name:
                print(ptr.data.shape, params_to_copy.shape)
            if 'normalization' in var_name and len(ptr.data.shape) != len(params_to_copy.shape):
                if reduce(__mul__, ptr.data.shape) != reduce(__mul__, params_to_copy.shape):
                    breakpoint()
                ptr.data = torch.from_numpy(params_to_copy).float().unsqueeze(-1).unsqueeze(-1).unsqueeze(0)
            else:
                if ptr.data.shape != params_to_copy.shape:
                    breakpoint()
                    pass
                else:
                    ptr.data = torch.from_numpy(params_to_copy).float()

    o1 = sess.run(outputs_tf, {
        image_a_pl: sources.numpy(),
        # image_b_pl: targets.numpy(),
        image_b_pl: sources.numpy(),
    })
    key1 = o1['keypoints_a']['centers']
    key1 = o1['keypoints_a']['heatmaps']
    o1 = o1['reconstructed_image_b']

    # o2 = t2(sources.to(device).float().transpose(1, -1), targets.to(device).float().transpose(1, -1))
    o2 = t2(sources.to(device).float().transpose(1, -1), sources.to(device).float().transpose(1, -1))
    key2 = o2['keypoints_a']['centers'].detach().numpy()
    key2 = o2['keypoints_a']['heatmaps'].permute(0, 2, 3, 1).detach().numpy()
    o2 = o2['reconstructed_image_b'].detach().transpose(1, -1).numpy()

    # plt.imshow(sources[0, :, :, 0])
    # plt.title('source')
    # plt.show()
    #
    # # plt.imshow(o1[0, :, :, 0])
    # plt.imshow(key1[0, :, :, 1])
    # plt.title('tf')
    # plt.show()
    #
    # # plt.imshow(o2[0, :, :, 0])
    # plt.imshow(key2[0, :, :, 1])
    # plt.title('pytorch')
    # plt.show()

    print("MAIN METRIC", np.abs(o1 - o2).mean())
    print("MAIN METRIC", np.abs(o1 - np.flip(o2, -1)).mean())
    print("MAIN METRIC", np.abs(o1 - o2.transpose(0, 2, 1, 3)).mean())
    print("MAIN METRIC", np.abs(o1 - np.flip(o2.transpose(0, 2, 1, 3), -1)).mean())
    # ICI PRINT KEY 1 AND KEY 2 and compare heatmaps
    print(np.abs(key1 - key2).mean())
    print(np.abs(key1 - np.flip(key2, -1)).mean())
    print("next")

    # o1 = sess.run(encoder.debug_placeholders[1], {
    #     image_a_pl: sources.numpy(),
    #     image_b_pl: sources.numpy(),
    # })

    # o1 = sess.run(encoder.debug_placeholders[-1], {
    #     image_a_pl: sources.numpy(),
    #     image_b_pl: sources.numpy(),
    # })

    # o1 = sess.run(keypointer.debug_placeholders, {
    #     image_a_pl: sources.numpy(),
    #     image_b_pl: sources.numpy(),
    # })
    #
    # o1 = sess.run(t1.debug_placeholders[0], {
    #     image_a_pl: sources.numpy(),
    #     image_b_pl: sources.numpy(),
    # })
    #
    # o1 = sess.run(t1.debug_placeholders[1], {
    #     image_a_pl: sources.numpy(),
    #     image_b_pl: sources.numpy(),
    # })
    #
    # o1 = sess.run(decoder.debug_placeholders[1], {
    #     image_a_pl: sources.numpy(),
    #     image_b_pl: sources.numpy(),
    # })
    #
    o1 = sess.run(outputs_tf, {
        image_a_pl: sources.numpy(),
        image_b_pl: sources.numpy(),
    })
    o1 = o1['reconstructed_image_b']

    # o2 = t2.encoder.net[0](sources.to(device).float().transpose(1, -1))
    # o2 = t2.encoder.net[1](o2)
    # o2 = t2.encoder.net[2](o2)
    o2 = t2.encoder(sources.to(device).float().transpose(1, -1))
    o2p = t2.keypointer(sources.to(device).float().transpose(1, -1))
    o2 = t2.masking_features(5, o2, o2, o2p, o2p)
    # o2 = o2.detach().transpose(1, -1).numpy()
    # o2 = t2.decoder.layers[0](o2)
    # o2 = t2.decoder.layers[1](o2)
    # o2 = t2.decoder.layers[2](o2)
    # o2 = t2.decoder.layers[3](o2)
    # o2 = t2.decoder.layers[4](o2)
    # o2 = t2.decoder.layers[5](o2)
    # o2 = t2.decoder.layers[6](o2)
    # o2 = t2.decoder.layers[7](o2)
    # o2 = t2.decoder.layers[8](o2)
    o2 = t2.decoder(o2)
    o2 = o2.detach().transpose(1, -1).numpy()

    print(np.abs(o1 - o2).mean())
    print(np.abs(o1 - np.flip(o2, -1)).mean())

    # plt.imshow(sources[0, :, :, 0])
    # plt.title('source')
    # plt.show()
    #
    # plt.imshow(o1[0, :, :, 0])
    # plt.title('tf')
    # plt.show()
    #
    # plt.imshow(o2[0, :, :, 0])
    # plt.title('pytorch')
    # plt.show()

    # breakpoint()
    print("next2")

    # from TF to pytorch
    inter = sess.run(outputs_tf, {
        image_a_pl: sources.numpy(),
        image_b_pl: sources.numpy(),
    })

    o3 = t2.masking_features(5, torch.from_numpy(inter["features_a"]).transpose(1, -1),
                             torch.from_numpy(inter["features_b"]).transpose(1, -1),
                             {"centers": torch.from_numpy(inter["keypoints_a"]["centers"]),
                              "heatmaps": torch.from_numpy(inter["keypoints_a"]["heatmaps"]).transpose(1, -1)},
                             {"centers": torch.from_numpy(inter["keypoints_b"]["centers"]),
                              "heatmaps": torch.from_numpy(inter["keypoints_b"]["heatmaps"]).transpose(1, -1)})
    # o3 = t2.decoder.layers[0](o3)
    # o3 = t2.decoder.layers[1](o3)
    # o3 = t2.decoder.layers[2](o3)
    # o3 = t2.decoder.layers[3](o3)
    # o3 = t2.decoder.layers[4](o3)
    # o3 = t2.decoder.layers[5](o3)
    # o3 = t2.decoder.layers[6](o3)
    # o3 = t2.decoder.layers[7](o3)
    # o3 = t2.decoder.layers[8](o3)
    o3 = t2.decoder(o3)
    o3 = o3.detach().transpose(1, -1).numpy()

    print(np.abs(o1 - o3).mean())
    print(np.abs(o1 - np.flip(o3, -1)).mean())
    print("next3")

    # breakpoint()

    inp = sess.run(decoder.debug_placeholders[1], {
        image_a_pl: sources.numpy(),
        image_b_pl: sources.numpy(),
    })

    o1 = sess.run(decoder.debug_placeholders[2], {
        image_a_pl: sources.numpy(),
        image_b_pl: sources.numpy(),
    })

    #ReLU + Interpolate
    o3 = t2.decoder.layers[5](torch.from_numpy(inp).transpose(-1, 1))
    o3 = t2.decoder.layers[6](o3)
    o3 = o3.detach().transpose(1, -1).numpy()

    plt.imshow(o1[0, :, :, 0])
    plt.title('tf')
    plt.show()

    plt.imshow(o3[0, :, :, 0])
    plt.title('pytorch')
    plt.show()

    print(np.abs(o1 - o3).mean())
    print(np.abs(o1 - np.flip(o3, -1)).mean())
    print("next4")

breakpoint()
