import torch
import itertools
import numpy as np


perm = [l for l in itertools.permutations(range(5))]
perm = torch.from_numpy(np.array(perm))
Amain=torch.rand(5,3).softmax(-1)

Amain = torch.tensor([[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1]]).float()
Amain = torch.tensor([[1, 2, 3], [1, 2, 3], [1, 2, 3], [1, 2, 3], [1, 2, 3]]).float()
Amain = torch.tensor([[3, 2, 1], [3, 2, 1], [3, 2, 1], [3, 2, 1], [3, 2, 1]]).float()
Amain = torch.tensor([[2, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1]]).float()
#Amain = Amain.softmax(-1)
Amain=torch.rand(5,3)
Amain = Amain / Amain.sum(-1)[:, None]

Apf = []
for i in range(perm.shape[0]):
    A = Amain[perm[i]]

    l1 = torch.nn.functional.one_hot(torch.multinomial(A[0], num_samples=50000, replacement=True), 3)

    prob2 = torch.ones(50000, 3)
    prob2[:,0] *= (1-l1[:, 0])
    prob2 *= A[1]
    prob2 = prob2 / prob2.sum(-1)[:, None]
    l2 = torch.nn.functional.one_hot(torch.multinomial(prob2, num_samples=1), 3)[:, 0, :]

    prob3 = torch.ones(50000, 3)
    prob3[:,0] *= (1-l1[:, 0]) * (1-l2[:, 0])
    prob3[:,1:3] *= torch.minimum(2-l1[:, 1:3]-l2[:, 1:3], torch.tensor(1))
    prob3 *= A[2]
    prob3 = prob3 / prob3.sum(-1)[:, None]
    l3 = torch.nn.functional.one_hot(torch.multinomial(prob3, num_samples=1), 3)[:, 0, :]

    prob4 = torch.ones(50000, 3)
    prob4[:,0] *= (1-l1[:, 0]) * (1-l2[:, 0]) * (1-l3[:, 0])
    prob4[:,1:3] *= torch.minimum(2-l1[:, 1:3]-l2[:, 1:3]-l3[:, 1:3], torch.tensor(1))
    prob4 *= A[3]
    prob4 = prob4 / prob4.sum(-1)[:, None]
    l4 = torch.nn.functional.one_hot(torch.multinomial(prob4, num_samples=1), 3)[:, 0, :]

    prob5 = torch.ones(50000, 3)
    prob5[:,0] *= (1-l1[:, 0]) * (1-l2[:, 0]) * (1-l3[:, 0])  * (1-l4[:, 0])
    prob5[:,1:3] *= torch.minimum(2-l1[:, 1:3]-l2[:, 1:3]-l3[:, 1:3]-l4[:, 1:3], torch.tensor(1))
    prob5 *= A[4]
    prob5 = prob5 / prob5.sum(-1)[:, None]
    l5 = torch.nn.functional.one_hot(torch.multinomial(prob5, num_samples=1), 3)[:, 0, :]

    Ap=torch.stack((l1, l2, l3, l4, l5), 1)
    Apf.append(Ap.float().mean(0)[perm[i]])

Afinal = torch.stack(Apf, 0).mean(0)

Amain
Afinal

eq = torch.zeros(8, 15)
eq[0, :3] = Amain[0]
eq[1, 3:6] = Amain[1]
eq[2, 6:9] = Amain[2]
eq[3, 9:12] = Amain[3]
eq[4, 12:15] = Amain[4]

eq[5, 0] = Amain[0, 0]
eq[5, 3] = Amain[1, 0]
eq[5, 6] = Amain[2, 0]
eq[5, 9] = Amain[3, 0]
eq[5, 12] = Amain[4, 0]

eq[6, 1+0] = Amain[0, 1]
eq[6, 1+3] = Amain[1, 1]
eq[6, 1+6] = Amain[2, 1]
eq[6, 1+9] = Amain[3, 1]
eq[6, 1+12] = Amain[4, 1]

eq[7, 2+0] = Amain[0, 2]
eq[7, 2+3] = Amain[1, 2]
eq[7, 2+6] = Amain[2, 2]
eq[7, 2+9] = Amain[3, 2]
eq[7, 2+12] = Amain[4, 2]

constraints = torch.tensor([1, 1, 1, 1, 1, 1, 2, 2])

Afinal_direct = np.linalg.lstsq(eq.numpy(), constraints.float().numpy(), rcond=None)[0].reshape(5,3)
Afinal_direct = Amain * torch.from_numpy(Afinal_direct)

torch.tensor([1/5, 2/5, 2/5])

possib = [l for l in itertools.permutations([0, 1, 1, 2, 2])]
possib = torch.from_numpy(np.array(possib))

#p = []
#for pos in possib:
    #p.append(Amain.gather(-1, pos[:, None]).prod())
#p = torch.stack(p)
#p = Amain[None].repeat(120, 1, 1).gather(-1, possib[:, :, None]).prod(1)[:,0]
p = Amain.gather(1, possib.T).prod(0)
p = p/p.sum()

after = torch.zeros(5, 3)
for i in range(5):
    for j in range(3):
        after[i,j] = p[possib[:, i] == j].sum()

masks = torch.zeros(5, 3, 120)
for i in range(5):
    for j in range(3):
        masks[i,j] = possib[:, i] == j

after = (p * masks).sum(-1)
