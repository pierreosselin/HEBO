import itertools
import os

import numpy as np
import torch
from matplotlib import pyplot as plt

from utils.dataloader import STPosDataset
from utils.display import plot_keypoints_on_image
from utils.make_model import make_model
from utils.options import get_options

path = '/home/matthieu/exp/logictrans/base/true_th.instance_32_adamw_2_1/model.pt'
path = '/home/matthieu/exp/logictrans/base-slower-large/false_th.instance_32_adamw_1_1/model.pt'
path = '../model.1901.pt'
path = '/home/mattz/pycharm_project_669/logical-transporter/model.1.pt'

height = 128
device = torch.device("cpu")  # cuda:0, cpu
device = torch.device("cuda:0")
BATCH_SIZE = 64
env_name = 'PongNoFrameskip-v4'

opts = get_options()
torch.manual_seed(opts.seed)

t = make_model(opts, height, 5)
t.to(device)

# if os.path.isfile(path):
# t.load_state_dict(torch.load(path, map_location=torch.device('cpu')).state_dict())
t = torch.load(path, map_location=device)

(sources, targets) = torch.load(os.path.join(opts.data_path, env_name + '_pre.pt'))
(sources_pos, targets_pos) = torch.load(os.path.join(opts.data_path, env_name + '_pre.pos.pt'))

testdataloader = torch.utils.data.DataLoader(STPosDataset(sources, targets, sources_pos, targets_pos),
                                             batch_size=BATCH_SIZE,
                                             num_workers=0,
                                             shuffle=True,
                                             pin_memory=False)
perm = [l for l in itertools.permutations(range(sources_pos.shape[1]))]
perm = torch.from_numpy(np.array(perm)).to(device=device)

def unordered_distance(x, y):
    # NM2 tensors
    # perf = (x[:, perm] - y.unsqueeze(1)).norm(dim=(2, 3), p=2)
    # perf_flip = (x[:, perm] - y.flip(-1).unsqueeze(1)).norm(dim=(2, 3), p=2)
    #
    # return torch.stack((perf.min(-1)[0], perf_flip.min(-1)[0]), -1).min(-1)[0]
    # NM2 tensors
    perf = (x[:, perm] - y.unsqueeze(1)).norm(dim=-1, p=2)
    perf[perf < 0.2] = 0.0
    perf = perf.sum(-1)

    return perf.min(-1)[0]


def test_positions(model, testdataloader):
    model.eval()
    performance = []
    for i, data in enumerate(testdataloader, 0):
        with torch.set_grad_enabled(False):
            source, target, source_pos, target_pos = data
            source = source.to(device)
            target = target.to(device)
            source_pos = source_pos.to(device)
            target_pos = target_pos.to(device)
            outputs = model(source, target)

            d1 = unordered_distance(source_pos, outputs['keypoints_a']['centers'])
            d2 = unordered_distance(target_pos, outputs['keypoints_b']['centers'])
            performance.append((d1 + d2).mean())
        # break
    model.train()
    # print(time.time() - start_time)
    return torch.stack(performance).mean().cpu().numpy()


print(test_positions(t, testdataloader))

from torchvision import transforms
trans = transforms.ToTensor()
# for _ in range(8):
    # indexes = torch.randperm(sources.shape[0])[:BATCH_SIZE]
    # (source, target) = (sources[indexes].float()/255., targets[indexes].float()/255.)
    # (source, target) = (source.transpose(1, -1), target.transpose(1, -1))
    # source = trans(sources[indexes].numpy())
    # target = trans(target[indexes].numpy())

    # for i in range(BATCH_SIZE):
    #     plt.imshow((target[i].detach()*255).int().transpose(0, -1).cpu().numpy())
    #     plt.title('target')
    #     plt.show()
    #
    #     plt.imshow((source[i].detach()*255).int().transpose(0, -1).cpu().numpy())
    #     plt.title('source')
    #     plt.show()


for source, target, _, _ in testdataloader:
    source = source.to(device=device)
    target = target.to(device=device)
    break
outputs = t(source, target)
# index = (outputs['reconstructed_image_b'] - target).norm(dim=(-1, -2, -3), p=2).argmax()
# index = (outputs['reconstructed_image_b'] - target).norm(dim=(-1, -2, -3), p=2).argmin()

trans = transforms.ToPILImage()
# for i in [index]:
for i in range(BATCH_SIZE):
    plt.imshow(trans(outputs['reconstructed_image_b'][i].detach()))
    plt.title('reconstruction')
    plt.show()

    img, _ = plot_keypoints_on_image(trans(target[i]),
                                     outputs['keypoints_b']['centers'][i].detach().cpu().numpy())
    plt.imshow(img)
    plt.title('target keypoints')
    plt.show()

    # plt.imshow((outputs['keypoints_b']['heatmaps'][i].sum(0).detach() * 255).int().transpose(0, -1).cpu().numpy())
    # plt.title('target heatmaps')
    # plt.show()

    img, _ = plot_keypoints_on_image(trans(source[i]),
                                     outputs['keypoints_a']['centers'][i].detach().cpu().numpy())
    plt.imshow(img)
    plt.title('source keypoints')
    plt.show()

    # plt.imshow((outputs['keypoints_a']['heatmaps'][i].sum(0).detach() * 255).int().transpose(0, -1).cpu().numpy())
    # plt.title('source heatmaps')
    # plt.show()

    breakpoint()
    plt.close()