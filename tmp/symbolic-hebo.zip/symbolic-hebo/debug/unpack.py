import torch
from PIL import Image
import os.path

env_name = "PongNoFrameskip-v4"

(sources, targets) = torch.load(env_name + '_uniq.pt')

os.mkdir('unpacked')
for i in range(sources.shape[0]):
    Image.fromarray(sources[i].numpy()).save(os.path.join('unpacked', 's%s.png' % i))
    Image.fromarray(targets[i].numpy()).save(os.path.join('unpacked', 't%s.png' % i))

