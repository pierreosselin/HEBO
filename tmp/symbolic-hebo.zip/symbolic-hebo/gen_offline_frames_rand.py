import math
import pickle
import time

import numpy as np
import ray.rllib.env.wrappers.atari_wrappers
from joblib import Parallel, delayed
import os.path
import torch
import cv2
from matplotlib import pyplot as plt

from utils.display import plot_keypoints_on_image

CPU = 40
DATABASE = 100000
BATCH_SIZE = 64
# DATABASE = 160 # for debug
DEBUG_POSITIONS = True
DEBUG_POSITIONS = False
env_name = "PongNoFrameskip-v4"

if DEBUG_POSITIONS:
    CPU = 1


def downsample(img_batch):
    grey_batch = [cv2.cvtColor(img_batch[i].numpy(), cv2.COLOR_BGR2GRAY) for i in range(len(img_batch))]
    smaller_grey_batch = [cv2.resize(grey_batch[i], (64, 64), interpolation=cv2.INTER_AREA)
                          for i in range(len(grey_batch))]
    smaller_grey_batch = torch.stack([torch.from_numpy(i) for i in smaller_grey_batch])

    return smaller_grey_batch


def get_object_positions(env):
    # env.unwrapped.ale.setRAM(46, 165)
    ram = env.unwrapped.ale.getRAM()  # get emulator RAM state
    # env.render()
    # time.sleep(1)
    # cpu_score = ram[13]  # computer/ai opponent score
    # player_score = ram[14]  # your score
    cpu_paddle_y = ram[21]  # Y coordinate of computer paddle
    player_paddle_y = ram[51]  # Y coordinate of your paddle
    ball_x = ram[49]  # X coordinate of ball
    ball_y = ram[54]  # Y coordinate of ball
    # print("cpu_paddle_y %s, player_paddle_y %s, ball_x %s, ball_y %s" %
    #       (cpu_paddle_y, player_paddle_y, ball_x, ball_y))
    if ball_y == 0:
        return None
    positions = np.array([[90, 23], [170, 23], [66, cpu_paddle_y + 5], [ball_x, ball_y], [190, player_paddle_y + 5]])
    positions = positions.astype(np.float32)
    positions[:, 0] -= 48
    positions[:, 1] -= 12
    positions[:, 0] = ((2 * positions[:, 0]) / 160) - 1.
    positions[:, 1] = ((2 * positions[:, 1]) / 210) - 1.
    return positions


if not os.path.isfile(env_name + '_pre.pt'):
    print("building %s" % (env_name + '_pre.pt'))


    def collect(i):
        import random
        import gym
        from utils.wrappers import AtariPreprocessing
        shared_set_s = []
        shared_set_t = []

        shared_set_s_pos = []
        shared_set_t_pos = []

        if DEBUG_POSITIONS:
            firstCall = True
            plt.ion()
            fig, ax = plt.subplots()

        while len(shared_set_s) < (DATABASE // CPU):
            env = gym.make(env_name)
            noop = 0
            if "Pong" in env_name:
                noop = 60
            env = AtariPreprocessing(env, noop=noop, frame_skip=4, screen_size=128, grayscale_obs=False)
            # env = ray.rllib.env.wrappers.atari_wrappers.FireResetEnv(env)

            obs = env.reset()
            positions = get_object_positions(env)

            all_obs = []
            all_positions = []
            if positions is not None:
                all_obs.append(obs)
                all_positions.append(positions)

            for step in range(100):
                action = env.action_space.sample()
                obs, reward, done, info = env.step(action)
                positions = get_object_positions(env)
                if DEBUG_POSITIONS:
                    if positions is None:
                        img = obs
                    else:
                        img, _ = plot_keypoints_on_image(obs, positions)
                    if firstCall:
                        axim = ax.imshow(img)
                        firstCall = False
                    else:
                        axim.set_array(img)
                        fig.canvas.flush_events()
                    time.sleep(0.01)

                if positions is not None:
                    all_obs.append(obs)
                    all_positions.append(positions)
                if done:
                    break

            if DEBUG_POSITIONS:
                print("end of episode", step)
                breakpoint()

            mid = len(all_obs) // 2
            source_index = random.randint(0, mid)
            target_index = random.randint(mid, len(all_obs) - 1)
            shared_set_s.append(all_obs[source_index])
            shared_set_s_pos.append(all_positions[source_index])
            shared_set_t.append(all_obs[target_index])
            shared_set_t_pos.append(all_positions[target_index])
            L = len(shared_set_s)
            if i == 0 and L % 100 == 0:
                print("%s over %s" % (L, DATABASE // CPU), flush=True)
        return shared_set_s, shared_set_t, shared_set_s_pos, shared_set_t_pos


    if CPU == 1:
        shared_set_s, shared_set_t, shared_set_s_pos, shared_set_t_pos = collect(0)
    else:
        results = Parallel(n_jobs=CPU, backend="multiprocessing")(delayed(collect)(i) for i in range(CPU))
        shared_set_s, shared_set_t, shared_set_s_pos, shared_set_t_pos = zip(*results)

    shared_set_s = [item for sublist in shared_set_s for item in sublist]
    shared_set_t = [item for sublist in shared_set_t for item in sublist]
    shared_set_s_pos = [item for sublist in shared_set_s_pos for item in sublist]
    shared_set_t_pos = [item for sublist in shared_set_t_pos for item in sublist]

    sources = torch.stack([torch.from_numpy(i) for i in shared_set_s])
    targets = torch.stack([torch.from_numpy(i) for i in shared_set_t])

    sources_positions = torch.stack([torch.from_numpy(i) for i in shared_set_s_pos])
    targets_positions = torch.stack([torch.from_numpy(i) for i in shared_set_t_pos])

    print("saving %s shape %s" % (env_name + '_pre.pt', sources.shape))
    torch.save((sources, targets), env_name + '_pre.pt')
    print("saving %s shape %s" % (env_name + '_pre.pos.pt', sources_positions.shape))
    torch.save((sources_positions, targets_positions), env_name + '_pre.pos.pt')

if not os.path.isdir(os.path.join('data', env_name, 'pre')) or \
    not os.path.isfile(os.path.join('data', env_name, 'pre', 's0.npy')):
    os.makedirs(os.path.join('data', env_name, 'pre'), exist_ok=True)
    os.makedirs(os.path.join('data', env_name, 'pre.pos'), exist_ok=True)

    (sources, targets) = torch.load(env_name + '_pre.pt')
    (sources_pos, targets_pos) = torch.load(env_name + '_pre.pos.pt')
    for i in range(sources.shape[0]):
        np.save(os.path.join('data', env_name, 'pre', 's%s.npy' % i), sources[i].numpy())
        np.save(os.path.join('data', env_name, 'pre', 't%s.npy' % i), targets[i].numpy())
        np.save(os.path.join('data', env_name, 'pre.pos', 's%s.npy' % i), sources_pos[i].numpy())
        np.save(os.path.join('data', env_name, 'pre.pos', 't%s.npy' % i), targets_pos[i].numpy())

if not os.path.isfile(env_name + '_post.pt'):
    (sources, targets) = torch.load(env_name + '_pre.pt')
    (sources_pos, targets_pos) = torch.load(env_name + '_pre.pos.pt')
    BATCH_SIZE = 6  # for 16GB GPU
    sources_gpu = downsample(sources).cuda()
    targets_gpu = downsample(targets).cuda()


    # Wrong procedure?
    # for i in range(10000):
    #     if i % 100 == 0:
    #         print("DB diversity ", (sources_gpu - targets_gpu).float().norm(2, dim=(-1, -2)).mean())
    #
    #     old_db = torch.randint(sources_gpu.shape[0], size=(BATCH_SIZE,))
    #     new_db = torch.randint(sources_gpu.shape[0], size=(BATCH_SIZE,))
    #
    #     L2norm_old = (sources_gpu[old_db] - targets_gpu[old_db]).float().norm(2, dim=(-1, -2))
    #     L2norm_new = (sources_gpu[new_db] - targets_gpu[new_db]).float().norm(2, dim=(-1, -2))
    #
    #     index_old = old_db[L2norm_old < L2norm_new]
    #     index_new = new_db[L2norm_old < L2norm_new]
    #
    #     sources_gpu[index_old] = sources_gpu[index_new]
    #     sources[index_old] = sources[index_new]
    #     targets_gpu[index_old] = targets_gpu[index_new]
    #     targets[index_old] = targets[index_new]

    # def current_diversity_approx(sources_gpu, targets_gpu):
    #     total_frames = sources_gpu.size()[0]
    #     permutation = torch.randperm(total_frames)
    #
    #     diversity = 0
    #     for i in range(0, total_frames, BATCH_SIZE):
    #         indices = permutation[i:i + BATCH_SIZE]
    #
    #         l2source = (sources_gpu[indices, None] - sources_gpu[None]).float().norm(2, dim=(-1, -2)).mean(-1)
    #         l2target = (targets_gpu[indices, None] - targets_gpu[None]).float().norm(2, dim=(-1, -2)).mean(-1)
    #         diversity += (l2source + l2target).mean()
    #
    #         if i == 200:
    #             print("diversity ", diversity.cpu().numpy())
    #             break


    # # current_diversity_approx(sources_gpu, targets_gpu)
    # # new_indexes = []
    # total_new_pairs = 0
    # while total_new_pairs < 30000:
    #     # for i in range(1000):
    #     cond_all = []
    #     for _ in range(100 // BATCH_SIZE):
    #         old_db = torch.randint(sources_gpu.shape[0], size=(BATCH_SIZE,))
    #         # if len(new_indexes) <= BATCH_SIZE:
    #         new_db_s = torch.randint(sources_gpu.shape[0], size=(BATCH_SIZE,))
    #         new_db_t = torch.randint(sources_gpu.shape[0], size=(BATCH_SIZE,))
    #         # else:
    #         #     new_db = torch.randint(len(new_indexes), size=(BATCH_SIZE,))
    #         #     new_db = torch.from_numpy(np.array(new_indexes))[new_db]
    #
    #         l2source = (sources_gpu[old_db, None] - sources_gpu[None]).float().norm(2, dim=(-1, -2)).min(-1)[0]
    #         l2target = (targets_gpu[old_db, None] - targets_gpu[None]).float().norm(2, dim=(-1, -2)).min(-1)[0]
    #         l2_old_score = (l2source + l2target)
    #
    #         l2source_new = (sources_gpu[new_db_s, None] - sources_gpu[None]).float().norm(2, dim=(-1, -2)).min(-1)[0]
    #         l2target_new = (targets_gpu[new_db_t, None] - targets_gpu[None]).float().norm(2, dim=(-1, -2)).min(-1)[0]
    #         l2_new_score = (l2source_new + l2target_new)
    #
    #         cond = torch.rand_like(l2_old_score) < 0.05
    #         cond = cond + (l2_new_score > l2_old_score)
    #         total_new_pairs += cond.int().sum().cpu().numpy()
    #         cond_all.extend(cond.cpu().numpy())
    #         index_old = old_db[cond]
    #         # index_new = new_db[cond]
    #         index_new_s = new_db_s[cond]
    #         index_new_t = new_db_s[cond]
    #
    #         sources_gpu[index_old] = sources_gpu[index_new_s]
    #         sources[index_old] = sources[index_new_s]
    #         targets_gpu[index_old] = targets_gpu[index_new_t]
    #         targets[index_old] = targets[index_new_t]
    #         sources_pos[index_old] = sources_pos[index_new_s]
    #         targets_pos[index_old] = targets_pos[index_new_t]
    #         # new_indexes.extend(index_new.cpu().numpy())
    #
    #     # print(i, i * (100 // BATCH_SIZE) * BATCH_SIZE, len(new_indexes), np.mean(np.array(cond_all)))
    #     print(total_new_pairs, np.mean(np.array(cond_all)))
    #
    #     #     current_diversity_approx(sources_gpu, targets_gpu)
    #
    # torch.save((sources, targets), env_name + '_post.pt')
    # torch.save((sources_pos, targets_pos), env_name + '_post.pos.pt')

    start = time.time()
    unique_images = set()
    unique_sources = []
    unique_targets = []
    print("sorting unique index")
    for i in range(sources.shape[0]):
        # to_hash = '_'.join([str(c) for c in sources[i].numpy().flatten()])  # 28s to reach 1k
        # to_hash = tuple(sources[i].numpy().flatten())  # 3s to each 1k - 11602 uniques
        # to_hash = hash(pickle.dumps(sources[i]))  # too slow shouldn't call hash
        # to_hash = hash(pickle.dumps(sources[i].numpy().flatten())) # very fast but should not call hash
        # to_hash = pickle.dumps(sources[i].numpy().flatten())  # 0.08s to each 1k - 11602 uniques
        # to_hash = pickle.dumps(torch.cat((sources[i], targets[i]), -1).flatten().numpy())
        to_hash = pickle.dumps(sources[i].numpy().flatten())
        if to_hash not in unique_images:
            unique_images.add(to_hash)
            unique_sources.append(i)
        if i % 10000 == 0:
            print(i, len(unique_images), time.time() - start)

    for i in range(targets.shape[0]):
        to_hash = pickle.dumps(targets[i].numpy().flatten())
        if to_hash not in unique_images:
            unique_images.add(to_hash)
            unique_targets.append(i)
        if i % 10000 == 0:
            print(i, len(unique_images), time.time() - start)

    # torch.save((sources[unique_sources], targets[unique_targets]), env_name + '_uniq.pt')
    # torch.save((sources_pos[unique_sources], targets_pos[unique_targets]), env_name + '_uniq.pos.pt')

    print("select most diverse sources")
    sources_gpu = downsample(sources[unique_sources]).cuda()
    targets_gpu = downsample(targets[unique_targets]).cuda()
    D = []
    for i in range(len(unique_sources)):
        D.append((sources_gpu[i, None] - sources_gpu[None, :]).float().norm(dim=(-1, -2, -3), p=2).mean(-1))
        if i % 1000 == 0:
            print(i, time.time() - start)
    D = torch.stack(D)

    sources_sample = torch.multinomial(D.double() / D.double().sum(), sources.shape[0], replacement=True)
    targets_per_source = {}
    for s in sources_sample:
        s = int(s.cpu().numpy())
        if s in targets_per_source:
            targets_per_source[s] += 1
        else:
            targets_per_source[s] = 1

    print("select most diverse targets")
    new_sources = []
    new_targets = []
    new_sources_pos = []
    new_targets_pos = []
    all_selected_target = []

    for index, i in enumerate(torch.unique(sources_sample)):
        nb_of_insertion = targets_per_source[int(i.cpu().numpy())]
        selected_source = sources_gpu[i].unsqueeze(0)
        dist_to_source = (targets_gpu - selected_source).float().norm(dim=(-1, -2), p=2)
        # dist_to_source -= dist_to_source.max()
        # dist_to_source = dist_to_source.double().softmax(-1)
        prob_selecting_target = dist_to_source.double() / dist_to_source.double().sum()
        selected_target = torch.multinomial(prob_selecting_target, nb_of_insertion, replacement=False)
        all_selected_target.append(selected_target)

        for j in range(nb_of_insertion):
            new_sources.append(sources[unique_sources[i]])
            new_sources_pos.append(sources_pos[unique_sources[i]])
            new_targets.append(targets[unique_targets[selected_target[j]]])
            new_targets_pos.append(targets_pos[unique_targets[selected_target[j]]])

        if index % 1000 == 0:
            print(index, time.time() - start)

    print("%s source images used over %s" % (torch.unique(sources_sample).shape[0], len(unique_sources)))
    print("%s target images used over %s" % (
    torch.unique(torch.cat(all_selected_target).flatten()).shape[0], len(unique_targets)))

    new_sources = torch.stack(new_sources)
    new_targets = torch.stack(new_targets)

    new_sources_pos = torch.stack(new_sources_pos)
    new_targets_pos = torch.stack(new_targets_pos)

    torch.save((new_sources, new_targets), env_name + '_post.pt')
    torch.save((new_sources_pos, new_targets_pos), env_name + '_post.pos.pt')

# if not os.path.isfile(env_name + '_uniq2d.pt'):
#     (sources_uniq, targets_uniq) = torch.load(env_name + '_uniq.pt')
#     (sources_uniq_pos, targets_uniq_pos) = torch.load(env_name + '_uniq.pos.pt')
#
#     start = time.time()
#
#     merged_images = torch.cat((sources_uniq, targets_uniq), 0)
#     merged_positions = torch.cat((sources_uniq_pos, targets_uniq_pos), 0)
#
#     merged_images_cuda = downsample(merged_images).float().cuda()
#     distance_between_pair = torch.zeros(merged_images.shape[0], merged_images.shape[0]).cuda()
#     for i in range(merged_images.shape[0]):
#         distance_between_pair[i] = (merged_images_cuda[i, None] - merged_images_cuda[None, :]).norm(dim=(-1, -2), p=2)[
#             0]
#
#         if i % 1000 == 0:
#             print(i, time.time() - start)
#     merged_images_cuda = None
#
#     distance_to_others = distance_between_pair.mean(-1)[:, None] + distance_between_pair.mean(-2)[None, :]
#
#     for i in range(merged_images.shape[0]):
#         distance_to_others[i, :i + 1] *= 0.0
#         distance_between_pair[i, :i + 1] *= 0.0
#     upper_right = torch.triu(torch.ones(distance_to_others.shape[0], distance_to_others.shape[0]), diagonal=1)
#     upper_right = upper_right.bool()
#     distance_to_others = distance_to_others.cpu()[upper_right].flatten()
#     distance_between_pair = distance_between_pair.cpu()[upper_right].flatten()
#     costs = torch.stack((distance_to_others, distance_between_pair), -1)
#
#     # Faster than is_pareto_efficient_simple, but less readable.
#     def is_pareto_efficient(costs, return_mask=True):
#         """
#         Find the pareto-efficient points
#         :param costs: An (n_points, n_costs) array
#         :param return_mask: True to return a mask
#         :return: An array of indices of pareto-efficient points.
#             If return_mask is True, this will be an (n_points, ) boolean array
#             Otherwise it will be a (n_efficient_points, ) integer array of indices.
#         """
#         is_efficient = np.arange(costs.shape[0])
#         n_points = costs.shape[0]
#         next_point_index = 0  # Next index in the is_efficient array to search for
#         while next_point_index < len(costs):
#             nondominated_point_mask = np.any(costs > costs[next_point_index], axis=1)
#             nondominated_point_mask[next_point_index] = True
#             is_efficient = is_efficient[nondominated_point_mask]  # Remove dominated points
#             costs = costs[nondominated_point_mask]
#             next_point_index = np.sum(nondominated_point_mask[:next_point_index]) + 1
#         if return_mask:
#             is_efficient_mask = np.zeros(n_points, dtype=bool)
#             is_efficient_mask[is_efficient] = True
#             return is_efficient_mask
#         else:
#             return is_efficient
#
#     print("compute pareto pairs.")
#     sol = is_pareto_efficient(costs.numpy(), return_mask=False)
#     sol = torch.from_numpy(sol)
#     breakpoint()

if not os.path.isdir(os.path.join('data', env_name, 'post')) or \
    not os.path.isfile(os.path.join('data', env_name, 'post', 's0.npy')):
    os.makedirs(os.path.join('data', env_name, 'post'), exist_ok=True)
    os.makedirs(os.path.join('data', env_name, 'post.pos'), exist_ok=True)

    (sources, targets) = torch.load(env_name + '_post.pt')
    (sources_pos, targets_pos) = torch.load(env_name + '_post.pos.pt')
    for i in range(sources.shape[0]):
        np.save(os.path.join('data', env_name, 'post', 's%s.npy' % i), sources[i].numpy())
        np.save(os.path.join('data', env_name, 'post', 't%s.npy' % i), targets[i].numpy())
        np.save(os.path.join('data', env_name, 'post.pos', 's%s.npy' % i), sources_pos[i].numpy())
        np.save(os.path.join('data', env_name, 'post.pos', 't%s.npy' % i), targets_pos[i].numpy())


(sources, targets) = torch.load(env_name + '_post.pt')
(sources_pos, targets_pos) = torch.load(env_name + '_post.pos.pt')

breakpoint()

for _ in range(50):
    index = np.random.randint(targets.shape[0])
    # plt.imshow(targets[index].numpy())
    # plt.show()

    img, _ = plot_keypoints_on_image(targets[index].numpy(), targets_pos[index].numpy())
    plt.imshow(img)
    plt.title('targets')
    plt.show()

    img, _ = plot_keypoints_on_image(sources[index].numpy(), sources_pos[index].numpy())
    plt.imshow(img)
    plt.title('sources')
    plt.show()
