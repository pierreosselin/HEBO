import itertools
import os

import numpy as np
import torch

from utils.dataloader import STDataset, STPosDataset, STPretrainedDataset
from utils.make_model import make_model
from utils.options import get_options

BATCH_SIZE = 64
height = 128
keypoints = 5

opts = get_options()
env_name = opts.env
torch.manual_seed(opts.seed)
device = torch.device("cuda:0")  # cuda:0, cpu
torch.backends.cudnn.benchmark = True

##########
# Model
##########
t = make_model(opts, height, keypoints)
# t.load_state_dict(torch.load("/home/matthieu/exp/logictrans/base-pretrained-corrected-big/false_th.instance_128_adamw_3_1/model.3.pt",
#                                                      map_location=torch.device('cpu')).state_dict(), strict=True)
t.to(device)

optim_type = torch.optim.AdamW if opts.optimizer == "adamw" else torch.optim.Adam
# decay = []
# no_decay = []
# for name, param in t.named_parameters():
#     if '.2.' in name or '.6.' in name or 'encoder.net.10' in name or 'encoder.net.14' in name:
#         no_decay.append(param)
#     else:
#         decay.append(param)
#
# optimizer = optim_type([{'params': no_decay, 'weight_decay': 0.0},
#                         {'params': decay, 'weight_decay': 1e-2}])
optimizer = optim_type(t.parameters())
lr_scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, 0.95)
loss = torch.nn.MSELoss()

##########
# Data
##########
trainloader = torch.utils.data.DataLoader(STPretrainedDataset(os.path.join(opts.data_path, env_name)),
                                          batch_size=BATCH_SIZE,
                                          shuffle=True,
                                          num_workers=4,
                                          pin_memory=True,
                                          drop_last=True
                                          )

testdataloader = torch.utils.data.DataLoader(STPosDataset(os.path.join(opts.data_path, env_name)),
                                             batch_size=BATCH_SIZE,
                                             num_workers=8,
                                             pin_memory=True)
perm = [l for l in itertools.permutations(range(keypoints))]
perm = torch.from_numpy(np.array(perm)).to(device=device)


def unordered_distance(x, y):
    # NM2 tensors
    perf = (x[:, perm] - y.unsqueeze(1)).norm(dim=-1, p=2)
    perf[perf < 0.2] = 0.0
    perf = perf.sum(-1)

    return perf.min(-1)[0]


def test_positions(model, testdataloader):
    model.eval()
    performance = []
    for i, data in enumerate(testdataloader, 0):
        with torch.set_grad_enabled(False):
            source, target, source_pos, target_pos = data
            source = source.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            source_pos = source_pos.to(device, non_blocking=True)
            target_pos = target_pos.to(device, non_blocking=True)
            outputs = model(source, target)

            d1 = unordered_distance(source_pos, outputs['keypoints_a']['centers'])
            d2 = unordered_distance(target_pos, outputs['keypoints_b']['centers'])
            performance.append((d1 + d2).mean())
    model.train()
    return torch.stack(performance).mean().cpu().numpy()


##########
# Training
##########
training_results = open('learning.%s.csv' % opts.seed, "w")
testing_results = open('testing.%s.csv' % opts.seed, "w")

for e in range(opts.epoch):
    # tau = np.maximum(0.5, 2 * np.power(0.95, e))
    if e % 1 == 0 and e != 0:
        test_perf = test_positions(t, testdataloader)
        print("test", e, test_perf)
        testing_results.write("%s\n" % test_perf)
        testing_results.flush()

    for i, (source, target) in enumerate(trainloader):
    # for i, data in enumerate(testdataloader, 0):
        optimizer.zero_grad()
        # source, target, source_pos, target_pos = data
        source = source.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        outputs = t(source, target)
        loss_val = loss(outputs['reconstructed_image_b'], target)
        total_loss = loss_val

        if opts.model == "logic":
            loss_val2 = loss(outputs['glimpse_b'].detach(), outputs['decoded_glimpse_b'])
            total_loss += opts.ldec_coef * loss_val2
            # total_loss = loss_val2
        total_loss.backward()
        # max_norm = 10.0
        # for group in optimizer.param_groups:
        #     torch.nn.utils.clip_grad_norm_(
        #         group['params'],
        #         max_norm,
        #         norm_type=2
        #     )
        optimizer.step()

        if i % 100 == 0:
            if opts.model == "logic":
                print("train", loss_val.detach().cpu().numpy(), loss_val2.detach().cpu().numpy())
                training_results.write("%s,%s\n" % (loss_val.detach().cpu().numpy(),
                                                    loss_val2.detach().cpu().numpy()))
            else:
                print("train", loss_val.detach().cpu().numpy())
                training_results.write("%s\n" % loss_val.detach().cpu().numpy())
            training_results.flush()
            # print(time.time() - start_time)

    lr_scheduler.step()
    print("lr ", lr_scheduler.get_last_lr())
    torch.save(t, "model.%s.pt" % opts.seed)

test_perf = test_positions(t, testdataloader)
print("test", e + 1, test_perf)
testing_results.write("%s\n" % test_perf)
testing_results.flush()

training_results.close()
testing_results.close()
torch.save(t, "model.%s.pt" % opts.seed)
