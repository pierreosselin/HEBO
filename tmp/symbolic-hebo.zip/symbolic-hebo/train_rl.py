import socket
from typing import Optional, Dict, List

import gym
import numpy as np
import torch
import torch.nn as nn
from collections.abc import Sequence
import ray
from ray.rllib.env.wrappers.atari_wrappers import FrameStack, FireResetEnv
from ray import tune
from ray.rllib.agents.sac import SACTrainer
from ray.rllib.agents.ppo import PPOTrainer
from ray.rllib.utils.typing import ModelConfigDict, TensorType
from ray.tune.registry import register_env
from ray.rllib.models.torch.torch_modelv2 import TorchModelV2
from ray.rllib.agents.sac.sac_torch_model import SACTorchModel
from ray.rllib.models import ModelCatalog
from ray.rllib.models.torch.fcnet import FullyConnectedNetwork
from ray.rllib.models.torch.visionnet import VisionNetwork
from utils.wrappers import AtariPreprocessing, EasyDone
from utils.options import get_options
from utils.make_model import make_model

opts = get_options()
# ENV = 'PongNoFrameskip-v4'
ENV = 'PongNoFrameskip-v4'
opts.model = 'logic'
opts.stop_led_grad = True
DEBUG = True
DEBUG = False

print(socket.gethostname())
if socket.gethostname() == "gridlon01":
    TRAINER = SACTrainer
else:
    TRAINER = PPOTrainer

ray.shutdown()
if DEBUG:
    ray.init(local_mode=True)
else:
    if socket.gethostname() == "gridlon01":
        ray.init(num_gpus=0, num_cpus=40)
    else:
        ray.init(num_gpus=1, num_cpus=33)
    # breakpoint()
    # ray.init(num_gpus=1, num_cpus=16)


def make_env(env_config):
    env = gym.make(ENV)
    noop = 60
    env = AtariPreprocessing(env, noop=noop, frame_skip=4, screen_size=128, grayscale_obs=False)
    if "FIRE" in env.unwrapped.get_action_meanings():
        env = FireResetEnv(env)
    env = EasyDone(env)
    env = FrameStack(env, 4)
    return env


register_env(ENV, make_env)


def concat_shape(*shapes):
    output = []
    for s in shapes:
        if isinstance(s, Sequence):
            output.extend(s)
        else:
            output.append(int(s))
    return tuple(output)


def broadcast(tensor, dim, size):
    if dim < 0:
        dim += tensor.dim()
    assert tensor.size(dim) == 1
    shape = tensor.size()
    return tensor.expand(concat_shape(shape[:dim], size, shape[dim + 1:]))


def meshgrid(input1, input2=None, dim=1):
    """Perform np.meshgrid along given axis. It will generate a new dimension after dim."""
    if input2 is None:
        input2 = input1
    if dim < 0:
        dim += input1.dim()
    n, m = input1.size(dim), input2.size(dim)
    x = broadcast(input1.unsqueeze(dim + 1), dim + 1, m)
    y = broadcast(input2.unsqueeze(dim + 0), dim + 0, n)
    return x, y


class InputTransformMethod:
    CONCAT = 'concat'
    DIFF = 'diff'
    CMP_DIFF = 'cmp_diff'
    CMP = 'cmp'
    CMP_NOT = 'cmpnot'


class InputTransform(nn.Module):
    """Transform the unary predicates to binary predicates by operations."""

    def __init__(self, method, exclude_self=True):
        super().__init__()
        self.method = method
        self.exclude_self = exclude_self

    def forward(self, inputs):
        assert inputs.dim() == 3

        x, y = meshgrid(inputs, dim=1)

        if self.method == InputTransformMethod.CONCAT:
            combined = torch.cat((x, y), dim=3)
        elif self.method == InputTransformMethod.DIFF:
            combined = x - y
        elif self.method == InputTransformMethod.CMP_DIFF:
            zero = torch.zeros_like(x)
            combined = torch.maximum(x - y, zero) / 2.
            combined2 = torch.maximum(y - x, zero) / 2.
            combined = torch.cat((combined, combined2), -1)
        elif self.method == InputTransformMethod.CMP:
            combined = torch.cat([x < y, x == y, x > y], dim=3)
        elif self.method == InputTransformMethod.CMP_NOT:
            combined = torch.cat([x < y, x == y], dim=3)
        else:
            raise ValueError('Unknown input transform method: {}.'.format(self.method))

        if self.exclude_self:
            combined = meshgrid_exclude_self(combined, dim=1)
        return combined.float()

    def get_output_dim(self, input_dim):
        if self.method == InputTransformMethod.CONCAT:
            return input_dim * 2
        elif self.method == InputTransformMethod.DIFF:
            return input_dim
        elif self.method == InputTransformMethod.CMP_DIFF:
            return input_dim * 2
        elif self.method == InputTransformMethod.CMP:
            return input_dim * 3
        elif self.method == InputTransformMethod.CMP_NOT:
            return input_dim * 2
        else:
            raise ValueError('Unknown input transform method: {}.'.format(self.method))


class LogicalTransporterMLP(TorchModelV2, nn.Module):

    def __init__(self, obs_space: gym.spaces.Space, action_space: gym.spaces.Space, num_outputs: int,
                 model_config: ModelConfigDict, name: str, shared_vf=True):
        super().__init__(obs_space, action_space, num_outputs, model_config, name)
        nn.Module.__init__(self)
        # obs_space_logic = gym.spaces.box.Box(low=0.0, high=1.0, shape=(80,))
        obs_space_logic = gym.spaces.box.Box(low=-1.0, high=1.0, shape=(16,))
        self.mlp = FullyConnectedNetwork(obs_space_logic, action_space, num_outputs, model_config, name)
        self.transform = InputTransform(InputTransformMethod.CMP_DIFF, exclude_self=False)
        self.ltransporter = make_model(opts, 128, 5)
        if socket.gethostname() == "gridlon01":
            self.ltransporter.load_state_dict(torch.load("/home/matthieu/git/logical-transporter/working.pt",
                                                     map_location=torch.device('cpu')).state_dict(), strict=False)
        else:
            self.ltransporter.load_state_dict(torch.load("/home/mattz/pycharm_project_669/logical-transporter/working.pt",
                                                     map_location=torch.device('cpu')).state_dict(), strict=False)

        # model_config['conv_filters'] = [[16, [8, 8], 4], [32, [8, 8], 3], [256, [10, 10], 2]]
        # vf_space = gym.spaces.box.Box(
        #     float("-inf"),
        #     float("inf"),
        #     shape=(1,))
        # self.mlp_vf = VisionNetwork(obs_space, vf_space, 1, model_config, name)

    def forward(self, input_dict: Dict[str, TensorType], state: List[TensorType], seq_lens: TensorType) -> (
            TensorType, List[TensorType]):

        # print(input_dict['obs'].device, input_dict['obs'].dtype, input_dict['obs'].shape[0])

        f = input_dict['obs'].permute(0, 3, 1, 2).contiguous()
        f = f.to(dtype=torch.float32).div(255)
        f = f.view(-1, 3, *f.shape[-2:])


        ltransout = self.ltransporter(f, None, same_image=True, compute_logic=True)
        unary = ltransout['logic_embedding_b']  # .detach()
        binary = ltransout['keypoints_a']['centers'].detach()
        # binary = self.transform(ltransout['keypoints_a']['centers'].detach())
        # binary = self.transform(ltransout['keypoints_a']['centers'])

        # unary = unary.reshape(*input_dict['obs'].shape[:2], *unary.shape[1:])
        # unary = unary.reshape(unary.shape[0], -1, unary.shape[-1])

        binary = binary[:, [3, 4], :]
        binary = binary.reshape(binary.shape[0], -1, binary.shape[-1])

        # if f.shape[0] != 1:
        #     print(f.device, f.shape[0], self.ltransporter.training, unary.requires_grad)
        # elif np.random.rand() < 0.01:
        #     print(f.device, f.shape[0], self.ltransporter.training, unary.requires_grad)
        # if f.shape[0] == 1 and f.device == 'cuda:0':
        #     breakpoint()
        # if np.random.rand() < 0.01:
        #     print(torch.cat([param.view(1, -1) for param in self.ltransporter.parameters()], -1).abs().sum())
        #     print(torch.cat([param.view(1, -1) for param in self.mlp.parameters()], -1).abs().sum())

        if DEBUG and f.shape[0] != 1 and not (f[0] == 0).all():
            print(f.device, f.shape[0], self.ltransporter.training, unary.requires_grad)
            print(torch.cat([param.view(1, -1) for param in self.ltransporter.parameters()], -1).abs().sum())

            import matplotlib.pyplot as plt
            from torchvision import transforms
            from utils.display import plot_keypoints_on_image
            trans2 = transforms.ToPILImage()
            img, _ = plot_keypoints_on_image(trans2(f[0]),
                                             # ltransout['keypoints_a']['centers'][0].detach().cpu().numpy())
                                             binary.view(-1, 2).detach().cpu().numpy())
            plt.imshow(img)
            plt.show()
            # print(unary[:, :, :3])
            print(binary[:, :, :])
            breakpoint()

        # f = [unary, binary]
        # f = torch.cat((f[0].view(unary.shape[0], -1), f[1].view(unary.shape[0], -1)), -1)
        f = binary.reshape(input_dict['obs'].shape[0], -1)
        f = {"obs": f, "obs_flat": f}
        pol = self.mlp(f, state, seq_lens)

        # input_dict['obs'] = input_dict['obs'].permute(0, 2, 3, 4, 1).reshape(input_dict['obs'].shape[0], *input_dict['obs'].shape[2:4], -1)
        # self.vf_last_value = self.mlp_vf(input_dict, state, seq_lens)
        return pol

    def value_function(self) -> TensorType:
        v = self.mlp.value_function()
        return v
        # return self.vf_last_value[0][:, 0]


# The custom model that will be wrapped by an LSTM.
class MyCustomSAC(SACTorchModel):

    def __init__(self, obs_space: gym.spaces.Space, action_space: gym.spaces.Space, num_outputs: Optional[int],
                 model_config: ModelConfigDict, name: str, policy_model_config: ModelConfigDict = None,
                 q_model_config: ModelConfigDict = None, twin_q: bool = False, initial_alpha: float = 1.0,
                 target_entropy: Optional[float] = None):
        super().__init__(obs_space, action_space, num_outputs, model_config, name, policy_model_config, q_model_config,
                         twin_q, initial_alpha, target_entropy)

    def build_policy_model(self, obs_space, num_outputs, policy_model_config, name):
        # policy_model_config["conv_filters"] = [[16, [8, 8], 4], [32, [8, 8], 3], [256, [10, 10], 2]]
        # model = ModelCatalog.get_model_v2(
        #     obs_space,
        #     self.action_space,
        #     num_outputs,
        #     policy_model_config,
        #     framework="torch",
        #     name=name)
        model = LogicalTransporterMLP(
            obs_space,
            self.action_space,
            num_outputs,
            policy_model_config,
            name=name,
            shared_vf=False)
        return model

    def build_q_model(self, obs_space, action_space, num_outputs, q_model_config, name):
        q_model_config["conv_filters"] = [[16, [8, 8], 4], [32, [8, 8], 3], [256, [10, 10], 2]]
        return super().build_q_model(obs_space, action_space, num_outputs, q_model_config, name)


ModelCatalog.register_custom_model("logicaltransmlp", LogicalTransporterMLP)
ModelCatalog.register_custom_model("customSAC", MyCustomSAC)


if TRAINER == PPOTrainer:
    config = {
        # "use_critic": False,
        # "use_gae": False,
        "batch_mode": "truncate_episodes",
        # "batch_mode": "complete_episodes",
        "num_sgd_iter": 3,
        "clip_rewards": True,
        "lr": 0.00025,
        "vf_loss_coeff": 1.0,
        "rollout_fragment_length": 128,
        "clip_param": 0.1,
        "train_batch_size": 2048,
        # "kl_coeff": 0.5,
        "observation_filter": "NoFilter",
        # "entropy_coeff": 0.01,
        "entropy_coeff": 0.00,
        # "sgd_minibatch_size": 500,
        "sgd_minibatch_size": 64,
        "model": {
        #     "dim": 42,
        #     "vf_share_layers": True
            "custom_model": "logicaltransmlp",
        },
        "vf_clip_param": 10.0,
        "lambda": 0.95
    }
else:
    config = {
        "tau": 1.0,
        "clip_rewards": 1.0,
        "rollout_fragment_length": 1,
        # "policy_model": {
        #     "hidden_activation": "relu",
        #     "hidden_layer_sizes": [
        #         64
        #     ]
        # },
        "model": {
            "custom_model": "customSAC",
        },
        "n_step": 1,
        "metrics_smoothing_episodes": 5,
        "timesteps_per_iteration": 4,
        "train_batch_size": 64,
        "target_entropy": "auto",
        "replay_buffer_config": {
            "type": "LocalReplayBuffer",
            "capacity": int(100000),
        },
        "target_network_update_freq": 400 if not DEBUG else 1,
        # "learning_starts": 100000 if not DEBUG else 10,
        "learning_starts": 50000,
        "Q_model": {
            "hidden_activation": "relu",
            "hidden_layer_sizes": [
                64
            ],
        },
        "optimization": {
            "actor_learning_rate": 0.0003,
            "entropy_learning_rate": 0.0003,
            "critic_learning_rate": 0.0003
        },
        "no_done_at_end": False,
        "gamma": 0.99,
        "prioritized_replay": True
    }

shared_config = {
    "env": ENV,
    "framework": "torch",
    # === Parallelism ===
    # Whether to use a GPU for local optimization.
    "num_gpus": 1 if not socket.gethostname() == "gridlon01" else 0,
    # Number of workers for collecting samples with. This only makes sense
    # to increase if your environment is particularly slow to sample, or if
    # you"re using the Async or Ape-X optimizers.
    "num_workers": 32 if not DEBUG else 0,
    # Whether to allocate GPUs for workers (if > 0).
    "num_gpus_per_worker": 0,
    # Whether to allocate CPUs for workers (if > 0).
    "num_cpus_per_worker": 1,
    "num_envs_per_worker": 1,
    "log_level": "INFO" if DEBUG else "WARN",
    # "preprocessor_pref": "deepmind",
    "preprocessor_pref": None,
    "evaluation_interval": 10,
    # "monitor": True, #takes videos
    "record_env": False,
}

config.update(shared_config)

tune.run(TRAINER, config=config)
