import itertools
import os

import numpy as np
import torch

from utils.dataloader import STProbDataset, STPosDataset
from utils.make_model import make_model
from utils.options import get_options

BATCH_SIZE = 64
height = 128
keypoints = 5

opts = get_options()
env_name = opts.env
torch.manual_seed(opts.seed)
device = torch.device("cuda:0")  # cuda:0, cpu
torch.backends.cudnn.benchmark = True

##########
# Model
##########
t = make_model(opts, height, keypoints)
t.to(device)

optim_type = torch.optim.AdamW if opts.optimizer == "adamw" else torch.optim.Adam
# decay = []
# no_decay = []
# for name, param in t.named_parameters():
#     if '.2.' in name or '.6.' in name or 'encoder.net.10' in name or 'encoder.net.14' in name:
#         no_decay.append(param)
#     else:
#         decay.append(param)
#
# optimizer = optim_type([{'params': no_decay, 'weight_decay': 0.0},
#                         {'params': decay, 'weight_decay': 1e-2}])
optimizer = optim_type(t.parameters())
lr_scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, 0.95)
loss = torch.nn.MSELoss()

##########
# Data
##########
# start_time = time.time()
advstdb = STProbDataset(os.path.join(opts.data_path, env_name))
trainloader = torch.utils.data.DataLoader(advstdb,
                                           batch_size=BATCH_SIZE,
                                           shuffle=True,
                                           num_workers=4,
                                           pin_memory=True,
                                           drop_last=False)

testdataloader = torch.utils.data.DataLoader(STPosDataset(os.path.join(opts.data_path, env_name)),
                                             batch_size=BATCH_SIZE,
                                             num_workers=4,
                                             pin_memory=True)
perm = [l for l in itertools.permutations(range(keypoints))]
perm = torch.from_numpy(np.array(perm)).to(device=device)


def unordered_distance(x, y):
    # NM2 tensors
    perf = (x[:, perm] - y.unsqueeze(1)).norm(dim=-1, p=2)
    perf[perf < 0.2] = 0.0
    perf = perf.sum(-1)

    return perf.min(-1)[0]


def test_positions(model, testdataloader):
    model.eval()
    performance = []
    for i, (source, target, source_pos, target_pos) in enumerate(testdataloader):
        source = source.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        source_pos = source_pos.to(device, non_blocking=True)
        target_pos = target_pos.to(device, non_blocking=True)
        with torch.set_grad_enabled(False):
            outputs = model(source, target)

        d1 = unordered_distance(source_pos, outputs['keypoints_a']['centers'])
        d2 = unordered_distance(target_pos, outputs['keypoints_b']['centers'])
        performance.append((d1 + d2).mean().cpu())

    model.train()
    return torch.stack(performance).mean().numpy()


def update_sampling_prob(model, trainloader, advstdb):
    advstdb.sampling_mode = False
    for i, (source, target, idx) in enumerate(trainloader):
        source = source.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        with torch.set_grad_enabled(False):
            outputs = model(source, target)

        sampling_score = (outputs['reconstructed_image_b'] - target).norm(p=2, dim=(1, 2, 3))
        advstdb.update_pool(idx, sampling_score)


##########
# Training
##########
training_results = open('learning.%s.csv' % opts.seed, "w")
testing_results = open('testing.%s.csv' % opts.seed, "w")

for e in range(opts.epoch):
    if e % 2 == 0 and e != 0:
        test_perf = test_positions(t, testdataloader)
        print("test", e, test_perf)
        testing_results.write("%s\n" % test_perf)
        testing_results.flush()

    advstdb.sample()
    advstdb.sampling_mode = True

    for i, (source, target) in enumerate(trainloader):
        optimizer.zero_grad()
        source = source.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        outputs = t(source, target)

        loss_val = loss(outputs['reconstructed_image_b'], target)
        loss_val.backward()
        optimizer.step()

        if i % 100 == 0:
            print("train", loss_val.detach().cpu().numpy())
            training_results.write("%s\n" % loss_val.detach().cpu().numpy())
            training_results.flush()

    if e % 2 == 0 and e != 0:
        lr_scheduler.step()

    update_sampling_prob(t, trainloader, advstdb)
    print("lr ", lr_scheduler.get_last_lr())
    torch.save(t, "model.%s.pt" % opts.seed)

test_perf = test_positions(t, testdataloader)
print("test", e + 1, test_perf)
testing_results.write("%s\n" % test_perf)
testing_results.flush()

training_results.close()
testing_results.close()
torch.save(t, "model.%s.pt" % opts.seed)
