import torch
import torch as th
import torch.nn as nn
from functools import reduce
from operator import __add__
import numpy as np
from torch.nn import Parameter

# from https://github.com/deepmind/deepmind-research/blob/master/transporter/transporter.py
# note the same padding in tf
# note image in tf is NHWC, in pytorch is NCHW


def add_norm_layer(norm_type, net, filters, height):
    if norm_type is not None:
        if norm_type == "instance":
            net.append(SonnetNorm((2, 3), (1, filters, 1, 1)))
        elif norm_type == "layer":
            net.append(SonnetNorm((1, 2, 3), (1, filters, 1, 1)))
        elif norm_type == "th_layer":
            net.append(nn.LayerNorm((filters, height, height)))
        elif norm_type == "th_instance":
            net.append(nn.InstanceNorm2d(filters, affine=False))
        elif norm_type == "th_instance_affine":
            net.append(nn.InstanceNorm2d(filters, affine=True))
        elif norm_type == "th_batchnorm":
            net.append(nn.BatchNorm2d(filters))
        elif norm_type == "none":
            pass
        else:
            raise()


class Transporter(nn.Module):
    def __init__(self, encoder, decoder, keypointer):
        '''
        encoder: map images to features
        decoder: decode features to images
        keypointer: map images to keypoint masks
        '''
        super().__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.keypointer = keypointer

    def forward(self, image_a, image_b):
        '''
        image_a, image_b: [B,C,H,W]
        returns:
        reconstructed_image_b: [B,C,H,W]
        features_a, features_b: [B, N, F_h, F_w]
        keypoints_a, without gradient
        keypoints_b, with gradient
        '''
        with th.no_grad():
            image_a_features = self.encoder(image_a)
            image_a_keypoints = self.keypointer(image_a)

        image_b_features = self.encoder(image_b)
        image_b_keypoints = self.keypointer(image_b)

        if self.training:
            # Transport features
            num_keypoints = image_a_keypoints['heatmaps'].shape[1]
            transported_features = self.masking_features(num_keypoints, image_a_features, image_b_features,
                             image_a_keypoints, image_b_keypoints)

            reconstructed_image_b = self.decoder(transported_features)
        else:
            reconstructed_image_b = None

        return {
            'reconstructed_image_b': reconstructed_image_b,
            'features_a': image_a_features,
            'features_b': image_b_features,
            'keypoints_a': image_a_keypoints,
            'keypoints_b': image_b_keypoints,
        }

    def masking_features(self, num_keypoints, image_a_features, image_b_features,
                         image_a_keypoints, image_b_keypoints):
        transported_features = image_a_features
        for k in range(num_keypoints):
            mask_a = image_a_keypoints['heatmaps'][:, k, :, :].unsqueeze(1)
            mask_b = image_b_keypoints['heatmaps'][:, k, :, :].unsqueeze(1)

            # supress features from image a, around both keypoint locations.
            transported_features = (1 - mask_a) * (1 - mask_b) * transported_features

            # copy features from image b around keypoints for image b.
            transported_features += mask_b * image_b_features
        return transported_features


class Encoder(nn.Module):
    '''
    map an image to features,
    CNN with Relu
    '''

    def __init__(
            self,
            initial_height,
            input_channel=3,
            filters=(16, 16, 32, 32),
            kernel_sizes=(7, 3, 3, 3),
            strides=(1, 1, 2, 1),
            norm_type=None
    ):
        super().__init__()
        kernel_size = (kernel_sizes[0], kernel_sizes[0])
        padding = reduce(__add__, [(k // 2 + (k - 2 * (k // 2)) - 1, k // 2) for k in kernel_size[::-1]])
        height = initial_height
        net = []
        net.append(nn.ZeroPad2d(padding))  # TF padding
        net.append(nn.Conv2d(input_channel, filters[0], kernel_sizes[0], strides[0]))
        height = int(height/strides[0])
        add_norm_layer(norm_type, net, filters[0], height)
        net.append(nn.ReLU())
        for i in range(1, len(filters)):
            kernel_size = (kernel_sizes[i], kernel_sizes[i])
            padding = reduce(__add__, [(k // 2 + (k - 2 * (k // 2)) - 1, k // 2) for k in kernel_size[::-1]])
            if strides[i] == 2:
                padding = list(padding)
                padding[1] += padding[0]
                padding[3] += padding[2]
                padding[0] = padding[2] = 0
            net.append(nn.ZeroPad2d(padding))
            net.append(nn.Conv2d(filters[i - 1], filters[i], kernel_sizes[i], strides[i], ))
            height = int(height/strides[i])
            add_norm_layer(norm_type, net, filters[i], height)
            net.append(nn.ReLU())
        self.net = nn.Sequential(*net)

    def forward(self, image):
        '''
        image:[B,C,H,W]
        return: [B,N,F_h,F_w], N=4*filters
        '''
        feature = self.net(image)
        return feature


class Decoder(nn.Module):  # decoder reconstruction network
    def __init__(self, initial_filters, decoder_num_filters, init_height, last_height, output_channels=3, norm_type=None):
        super().__init__()
        kernel_size = (3, 3)
        padding = reduce(__add__, [(k // 2 + (k - 2 * (k // 2)) - 1, k // 2) for k in kernel_size[::-1]])

        height = init_height
        net = []
        prev_filters = initial_filters
        filters = decoder_num_filters
        while height <= last_height:
            net.append(nn.ZeroPad2d(padding))
            net.append(nn.Conv2d(prev_filters, filters, 3, 1))
            prev_filters = filters
            add_norm_layer(norm_type, net, filters, height)
            net.append(nn.ReLU())

            if height == last_height:
                net.append(nn.ZeroPad2d(padding))
                net.append(nn.Conv2d(prev_filters, output_channels, 3, 1))
                break
            else:
                net.append(nn.ZeroPad2d(padding))
                net.append(nn.Conv2d(prev_filters, filters, 3, 1))
                prev_filters = filters
                add_norm_layer(norm_type, net, filters, height)
                net.append(nn.ReLU())

            height *= 2
            net.append(Interpolate())

            if filters >= 8:
                filters //= 2

        self.layers = nn.Sequential(*net)

    def forward(self, features):
        '''
        features: [B,N,F_h,F_w]
        '''
        return self.layers(features)


class KeyPointer(nn.Module):  # extract keypoints from an image
    def __init__(self, num_keypoints, keypoint_encoder, gauss_std, initial_filters):
        super().__init__()
        self.num_keypoints = num_keypoints
        self.keypoint_encoder = keypoint_encoder
        self.gauss_std = gauss_std
        self.net = nn.Conv2d(initial_filters, self.num_keypoints, 1, 1)

    def forward(self, image):
        # image [B,C,H,W]
        image_features = self.keypoint_encoder(image)
        keypoint_features = self.net(image_features)
        return self.get_keypoint_data_from_feature_map(keypoint_features, self.gauss_std)

    def get_keypoint_data_from_feature_map(self, feature_map, gauss_std):
        '''
        feature_map:[B,K,H,W]
        centers: [B,K,2]
        heatmaps: [B,K,H,W]
        '''
        gauss_mu = self.get_keypoint_mus(feature_map)
        map_size = feature_map.shape[2:4]
        gauss_maps = self.get_gaussian_maps(gauss_mu, map_size, 1.0 / gauss_std)
        return {
            "centers": gauss_mu,
            "heatmaps": gauss_maps
        }

    def get_keypoint_mus(self, keypoint_features):
        # keypoint_features [B,K,F_h,F_w]
        # gauss_mu: [B,K,2], in [-1,1], first element is y, second is x
        gauss_y = self.get_coord(keypoint_features, 1)
        gauss_x = self.get_coord(keypoint_features, 2)
        gauss_mu = th.stack([gauss_x, gauss_y], dim=2)
        return gauss_mu

    def get_coord(self, features, dim):
        other_dim = 1 if dim == 2 else 2
        dim_size = features.shape[dim + 1]

        # Compute nomalized weight for each row/column along the axis
        g_c_prob = th.mean(features, dim=other_dim + 1, keepdim=False)
        g_c_prob = nn.Softmax(dim=2)(g_c_prob)

        # Linear combination of the interval [-1,1] using the normalized weights to
        # give a single coordinate in the same interval [-1,1]
        scale = th.linspace(-1.0, 1.0, dim_size, device=g_c_prob.device).reshape([1, 1, dim_size])
        coordinate = th.sum(g_c_prob * scale, dim=2, keepdim=False)
        return coordinate

    def get_gaussian_maps(self, mu, map_size, inv_std, power=2):
        # transforms keypoint center to gaussian masks
        mu_x, mu_y = mu[:, :, 0:1], mu[:, :, 1:2]

        y = th.linspace(-1., 1., map_size[0], dtype=torch.float32, device=mu.device)
        x = th.linspace(-1., 1., map_size[1], dtype=torch.float32, device=mu.device)

        mu_y, mu_x = mu_y.unsqueeze(-1), mu_x.unsqueeze(-1)

        y = y.reshape([1, 1, map_size[0], 1])
        x = x.reshape([1, 1, 1, map_size[1]])

        g_y = th.pow(y - mu_y, power)
        g_x = th.pow(x - mu_x, power)
        # dist = (g_y + g_x) * np.power(inv_std, power)
        # g_yx = th.exp(-dist)
        # return g_yx
        # gamma = 0.2
        gamma2 = 0.04
        gamma3 = 0.008
        denom = th.pow((g_y + g_x + gamma2), 1.5)
        return gamma3 / denom


class Interpolate(nn.Module):
    def __init__(self):
        super(Interpolate, self).__init__()
        self.interp = nn.functional.interpolate

    def forward(self, x):
        x = self.interp(x, scale_factor=2., mode='bilinear', align_corners=True, recompute_scale_factor=True)
        return x


class SonnetNorm(nn.Module):
    def __init__(self, axis, shapes):
        super(SonnetNorm, self).__init__()
        self.axis = axis
        self.weight = Parameter(torch.Tensor(*shapes))
        self.bias = Parameter(torch.Tensor(*shapes))
        nn.init.uniform_(self.weight, 0.5, 2)
        nn.init.uniform_(self.bias, -1, 1)

    def forward(self, x):
        mean = x.mean(self.axis, keepdim=True)
        var = x.var(self.axis, keepdim=True, unbiased=True)

        inv = (var + 1e-5).rsqrt()

        # return x * inv + (self.bias - mean * inv)
        return self.weight * (x * inv + (self.bias - mean * inv)) + self.bias


# for debug purpose
class Identity(nn.Module):
    def __init__(self):
        super(Identity, self).__init__()

    def forward(self, x):
        return x
