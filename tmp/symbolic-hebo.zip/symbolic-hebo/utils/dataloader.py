import os

import torch
import numpy as np
from torchvision import transforms


class STDataset(torch.utils.data.Dataset):
    """ for training with diversity input should be _post """

    def __init__(self, path):
        super(STDataset, self).__init__()

        self.size = 100000
        self.path = os.path.join(path, 'post')
        self.trans = transforms.ToTensor()

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        sources = self.trans(np.load(os.path.join(self.path, 's%s.npy' % idx)))
        targets = self.trans(np.load(os.path.join(self.path, 't%s.npy' % idx)))
        if np.random.rand() <= 0.5:
            return sources, targets
        else:
            return targets, sources


class STPosDataset(torch.utils.data.Dataset):
    """ for testing input should be _pre """

    def __init__(self, path):
        super(STPosDataset, self).__init__()

        self.size = 100000
        self.path = os.path.join(path, 'pre')
        self.path_pos = os.path.join(path, 'pre.pos')
        self.trans = transforms.ToTensor()

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        sources = self.trans(np.load(os.path.join(self.path, 's%s.npy' % idx)))
        targets = self.trans(np.load(os.path.join(self.path, 't%s.npy' % idx)))
        sources_pos = torch.from_numpy(np.load(os.path.join(self.path_pos, 's%s.npy' % idx)))
        targets_pos = torch.from_numpy(np.load(os.path.join(self.path_pos, 't%s.npy' % idx)))
        return (sources, targets, sources_pos, targets_pos)


class STProbDataset(torch.utils.data.Dataset):
    """ for training with prob per pairs, input should be _post"""

    def __init__(self, path):
        super(STProbDataset, self).__init__()

        self.size = 100000
        self.prob = torch.ones(self.size) * (1. / self.size)
        self.trans = transforms.ToTensor()
        self.path = os.path.join(path, 'post')
        self.sampling_mode = True

    def __len__(self):
        if self.sampling_mode:
            return self.size // 2
        else:
            return self.size

    def update_pool(self, idx, score):
        self.prob[idx.cpu()] = score.cpu()

    def sample(self):
        self.prob = self.prob / self.prob.sum(-1)[None]
        self.index = torch.multinomial(self.prob, num_samples=self.size // 2, replacement=True)

    def __getitem__(self, idx):
        if self.sampling_mode:
            sources = self.trans(np.load(os.path.join(self.path, 's%s.npy' % self.index[idx].numpy())))
            targets = self.trans(np.load(os.path.join(self.path, 't%s.npy' % self.index[idx].numpy())))
            return sources, targets
        else:
            sources = self.trans(np.load(os.path.join(self.path, 's%s.npy' % idx)))
            targets = self.trans(np.load(os.path.join(self.path, 't%s.npy' % idx)))
            return sources, targets, idx


class STPretrainedDataset(torch.utils.data.Dataset):
    """ for training with diversity input should be _post """

    def __init__(self, path):
        super(STPretrainedDataset, self).__init__()

        self.path = os.path.join(path, 'pretrained')
        self.probs = np.load(self.path + '/frame_probs.npy')
        self.probs_index = np.load(self.path + '/frame_probs_index.npy')
        # from collections import Counter
        # all_pairs = []
        # for i in range(self.probs_index.shape[0]):
        #     all_pairs.extend([(i, j) for j in self.probs_index[i]])
        # ctr = Counter(frozenset(x) for x in all_pairs)
        # b = [ctr[frozenset(x)] for x in all_pairs]
        #np.unique(self.probs_index.flatten()).shape #61649
        self.index = np.load(self.path + '/frame_index.npy')
        self.size = self.probs.shape[0]
        self.trans = transforms.ToTensor()

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        sources = self.trans(np.load(os.path.join(self.path, self.index[idx])))
        # target_idx = self.probs_index[idx, np.random.randint(0, self.probs_index[idx].shape)][0]
        target_idx = np.random.randint(0, self.size)
        targets = self.trans(np.load(os.path.join(self.path, self.index[target_idx])))

        if np.random.rand() < 0.5:
            return targets, sources
        return sources, targets