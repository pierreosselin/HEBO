import argparse
import pprint as pp


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


def get_options():
    parser = argparse.ArgumentParser(description="Train transporter")

    parser.add_argument('--epoch', type=int, default=25, help='Number of training epoch')
    parser.add_argument('--env', type=str, default="PongNoFrameskip-v4", help="environment")
    parser.add_argument('--optimizer', type=str, default="adamw", help='optimizer')
    parser.add_argument('--seed', type=int, default=0, help='Random seed to use')
    parser.add_argument('--ldec_coef', type=float, default=0.0, help='additional logic decoder loss coefficient')
    parser.add_argument('--recons_coef', type=float, default=1.0, help='reconstruction loss coefficient')

    parser.add_argument('--model', default='transporter', choices=['transporter', 'logic'])
    parser.add_argument('--norm_type', default='th_instance', help="Which normalization to apply",
                        choices=['instance', 'th_instance', 'th_instance_affine',
                                 'layer', 'th_layer', 'th_batchnorm', 'none'])
    parser.add_argument('--small_arch', type=str2bool, default='true', help='Use smaller architecture')
    parser.add_argument('--stop_led_grad', type=str2bool, default='true', help='Stop logic encoder decoder grad')
    parser.add_argument('--data_path', type=str, default="data/", help="Where to load the offline data")
    parser.add_argument('--decoder_num_filters', type=int, default=128, help='Number of filter in the decoder')

    opts = parser.parse_args()
    pp.pprint(vars(opts))
    return opts
