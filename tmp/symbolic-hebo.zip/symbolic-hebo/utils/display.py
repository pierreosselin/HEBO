import PIL
import numpy as np
from PIL import Image, ImageDraw
from matplotlib import cm


def plot_keypoints_on_image(im, kpts, r=2, alpha=1.0, image_size=(128, 128)):
    if not isinstance(im, Image.Image):
        colored = len(im.shape) == 3
        im = (im * alpha).astype(np.uint8)
    else:
        colored = True
    scaled_kpts = kpts
    scaled_kpts = (scaled_kpts + 1.0) * 0.5 * np.array(list(image_size))[None, :]
    if not isinstance(im, Image.Image):
        im = Image.fromarray(im)
    if not colored:
        rgbimg = Image.new("RGB", im.size)
        rgbimg.paste(im)
        im = rgbimg

    im = im.resize(image_size, PIL.Image.BILINEAR)
    n_kpts = scaled_kpts.shape[0]
    colors = [tuple(c) for c in (cm.rainbow(np.linspace(0, 1, n_kpts)) * 255).astype(np.int32)]
    draw = ImageDraw.Draw(im)
    for i in range(len(scaled_kpts)):
        if np.isnan(scaled_kpts[i][0]) or np.isnan(scaled_kpts[i][1]):
            continue
        x, y = scaled_kpts[i].astype(np.int32)
        draw.ellipse((x - r, y - r, x + r, y + r), fill=colors[i])
        draw.text((x, y), str(i))
    return np.array(im), None
