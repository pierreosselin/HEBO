

def make_model(opts, height, nb_keypoints):
    norm_type = opts.norm_type
    decoder_num_filters = opts.decoder_num_filters
    small_arch = opts.small_arch
    if opts.model == "transporter":
        from transporter import KeyPointer, Encoder, Decoder, Transporter
    elif opts.model == "logic":
        from logic_transporter import KeyPointer, Encoder, Decoder, Transporter

    if small_arch:
        e = Encoder(height, norm_type=norm_type)
        ek = Encoder(height, norm_type=norm_type)
        # ek = Encoder(height, norm_type=norm_type, strides=(2, 2, 2, 4), filters=(16, 32, 32, 32))
        inner_channel = 32
        inner_height = 64
    else:
        e = Encoder(height, filters=(32, 32, 64, 64, 128, 128), kernel_sizes=(7, 3, 3, 3, 3, 3),
                    strides=(1, 1, 2, 1, 2, 1), norm_type=norm_type)
        ek = Encoder(height, filters=(32, 32, 64, 64, 128, 128), kernel_sizes=(7, 3, 3, 3, 3, 3),
                     strides=(1, 1, 2, 1, 2, 1), norm_type=norm_type)
        inner_channel = 128
        inner_height = 32

    d = Decoder(inner_channel, decoder_num_filters, inner_height, height, norm_type=norm_type)
    k = KeyPointer(nb_keypoints, ek, 0.1, initial_filters=inner_channel)
    if opts.model == "logic":
        t = Transporter(e, d, k, opts.stop_led_grad)
    else:
        t = Transporter(e, d, k)

    return t
