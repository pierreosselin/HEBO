import itertools

import torch
import torch as th
import torch.nn as nn
from functools import reduce
from operator import __add__, __mul__
import numpy as np
from torch.nn import Parameter

from utils.glimpse import extract_glimpse


# from https://github.com/deepmind/deepmind-research/blob/master/transporter/transporter.py
# note the same padding in tf
# note image in tf is NHWC, in pytorch is NCHW


def add_norm_layer(norm_type, net, filters, height):
    if norm_type is not None:
        if norm_type == "instance":
            net.append(SonnetNorm((2, 3), (1, filters, 1, 1)))
        elif norm_type == "layer":
            net.append(SonnetNorm((1, 2, 3), (1, filters, 1, 1)))
        elif norm_type == "th_layer":
            net.append(nn.LayerNorm((filters, height, height)))
        elif norm_type == "th_instance":
            net.append(nn.InstanceNorm2d(filters, affine=False))
        elif norm_type == "th_instance_affine":
            net.append(nn.InstanceNorm2d(filters, affine=True))
        elif norm_type == "th_batchnorm":
            net.append(nn.BatchNorm2d(filters))
        elif norm_type == "none":
            pass
        else:
            raise ()


"""
Utility function for computing output of convolutions
takes a tuple of (h,w) and returns a tuple of (h,w)
"""


def conv_output_shape(h_w, kernel_size=1, stride=1, pad=0, dilation=1):
    from math import floor
    if type(kernel_size) is not tuple:
        kernel_size = (kernel_size, kernel_size)
    h = floor(((h_w[0] + (2 * pad) - (dilation * (kernel_size[0] - 1)) - 1) / stride) + 1)
    w = floor(((h_w[1] + (2 * pad) - (dilation * (kernel_size[1] - 1)) - 1) / stride) + 1)
    return h, w


class Transporter(nn.Module):
    def __init__(self, encoder, decoder, keypointer, stop_led_grad):
        '''
        encoder: map images to features
        decoder: decode features to images
        keypointer: map images to keypoint masks
        '''
        super().__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.keypointer = keypointer
        self.stop_led_grad = stop_led_grad

        self.glimpse_size = (6, 6) if self.decoder.init_height == 32 else (8, 8)
        self.inner_filters = self.decoder.initial_filters
        self.nb_type_of_object = 3  # IsBall, IsPaddle, IsScore
        self.nb_unique_properties = 2  # IsPaddleMyColor, IsScoreMyColor
        self.nb_any_properties = 1  # IsOne
        self.total_unary_size = self.nb_type_of_object + self.nb_unique_properties + self.nb_any_properties
        configurations = [l for l in itertools.permutations([0, 1, 1, 2, 2])]
        configurations = torch.from_numpy(np.array(configurations))
        prob_masking = torch.zeros(5, 3, 120)
        for i in range(5):
            for j in range(3):
                prob_masking[i, j] = configurations[:, i] == j
        self.encoder2 = Encoder(128)

        flatten_weights = reduce(__mul__, conv_output_shape(self.glimpse_size, 3, 2)) * self.inner_filters
        self.log_encoder = nn.Sequential(nn.Conv2d(self.inner_filters, self.inner_filters, 3, 2),
                                         nn.Flatten(start_dim=1),
                                         nn.Linear(flatten_weights, self.total_unary_size))

        if self.decoder.init_height == 32:
            glimpse_size_sub = (self.glimpse_size[0] - 2, self.glimpse_size[1] - 2)
            kernel_stride = (3, 1)
        else:
            glimpse_size_sub = (self.glimpse_size[0] - 4, self.glimpse_size[1] - 4)
            kernel_stride = (2, 2)
        unflatten_weights = reduce(__mul__, glimpse_size_sub) * self.inner_filters
        self.log_decoder = nn.Sequential(nn.Linear(self.total_unary_size, unflatten_weights), nn.ReLU(),
                                         nn.Unflatten(1, (self.inner_filters, *glimpse_size_sub)),
                                         nn.ConvTranspose2d(self.inner_filters, self.inner_filters, *kernel_stride))

        rx = torch.arange(0, self.glimpse_size[0])
        ry = torch.arange(0, self.glimpse_size[1])
        x, y = torch.meshgrid(rx, ry, indexing='xy')
        ids = torch.arange(64)

        self.register_buffer('configurations', configurations)
        self.register_buffer('prob_masking', prob_masking)
        self.register_buffer('x', x)
        self.register_buffer('y', y)
        self.register_buffer('ids', ids)

        self.apply_post_gauss = True

    def forward(self, image_a, image_b, same_image=False, compute_logic=False):
        '''
        image_a, image_b: [B,C,H,W]
        returns:
        reconstructed_image_b: [B,C,H,W]
        features_a, features_b: [B, N, F_h, F_w]
        keypoints_a, without gradient
        keypoints_b, with gradient
        '''
        with th.no_grad():
            image_a_features = self.encoder(image_a)
            image_a_keypoints = self.keypointer(image_a)

        if same_image:
            image_b_features = image_a_features
            image_b_keypoints = image_a_keypoints
        else:
            image_b_features = self.encoder(image_b)
            image_b_keypoints = self.keypointer(image_b)

        # Transport features
        if self.training or compute_logic:
            num_keypoints = image_a_keypoints['heatmaps'].shape[1]
            transported_features, logic_embedding, glimpses, decoded_glimpse = self.masking_features(num_keypoints,
                                                                                                     image_a_features,
                                                                                                     image_b_features,
                                                                                                     image_a_keypoints,
                                                                                                     image_b_keypoints)
        else:
            logic_embedding = None
            glimpses = None
            decoded_glimpse = None

        if self.training:
            reconstructed_image_b = self.decoder(transported_features)
        else:
            reconstructed_image_b = None

        return {
            'reconstructed_image_b': reconstructed_image_b,
            'features_a': image_a_features,
            'features_b': image_b_features,
            'keypoints_a': image_a_keypoints,
            'keypoints_b': image_b_keypoints,
            'logic_embedding_b': logic_embedding,
            'glimpse_b': glimpses,
            'decoded_glimpse_b': decoded_glimpse
        }

    def masking_features(self, num_keypoints, image_a_features, image_b_features,
                         image_a_keypoints, image_b_keypoints):

        transported_features = image_a_features

        coords = image_b_keypoints['centers']
        coords = ((coords + 1.0) * 0.5 * torch.tensor([[self.decoder.init_height, self.decoder.init_height]],
                                                      device=image_b_features.device)).long()

        x = self.x[None, None] + coords[:, :, 0, None, None] - self.glimpse_size[0] // 2
        y = self.y[None, None] + coords[:, :, 1, None, None] - self.glimpse_size[1] // 2
        x.clamp_(0, self.decoder.init_height - 1)
        y.clamp_(0, self.decoder.init_height - 1)

        glimpses = []
        if image_a_features.shape[0] != self.ids.shape[0]:
            ids = torch.arange(image_a_features.shape[0], device=image_a_features.device)
        else:
            ids = self.ids

        for k in range(num_keypoints):
            mask_b = image_b_keypoints['heatmaps'][:, k, :, :].unsqueeze(1)

            # copy features from image b around keypoints for image b.
            if self.apply_post_gauss:
                input_to_log_encoder = image_b_features
            else:
                input_to_log_encoder = mask_b * image_b_features

            # diff_glimpse = extract_glimpse(input_to_log_encoder, size=self.glimpse_size,
            #                                        offsets=image_b_keypoints['centers'][:, k], centered=True)
            # indexing directly 4x times faster
            nondiff_glimpse = input_to_log_encoder[ids[:, None, None], :, y[:, k], x[:, k]].permute(0, 3, 1, 2)
            # glimpse = diff_glimpse
            glimpse = nondiff_glimpse

            glimpses.append(glimpse)

        glimpses = torch.stack(glimpses, 1).detach() if self.stop_led_grad else torch.stack(glimpses, 1)
        logic_embeddings = self.log_encoder(glimpses.view(-1, *glimpses.shape[2:]))
        logic_embeddings = logic_embeddings.view(*glimpses.shape[:2], self.total_unary_size)
        temporal_consistency = logic_embeddings[:, :, :self.nb_type_of_object + self.nb_unique_properties]
        temporal_consistency = temporal_consistency.mean(0).unsqueeze(0)

        # SOFTMAX with ad hoc constraints
        type_of_object = temporal_consistency[:, :, :3].softmax(-1)
        pa_inter_b = type_of_object.gather(2, self.configurations.T[None]).prod(1)
        # gnoise = pa_inter_b.mean() * 0.001 * -torch.empty_like(pa_inter_b, memory_format=torch.legacy_contiguous_format).exponential_().log()
        # print(pa_inter_b.mean(), gnoise.mean())
        # pa_inter_b = pa_inter_b + gnoise
        # index = pa_inter_b.max(-1, keepdim=True)[1]
        # y_hard = torch.zeros_like(pa_inter_b, memory_format=torch.legacy_contiguous_format).scatter_(-1, index, 1.0)
        # pa_inter_b = y_hard - pa_inter_b.detach() + pa_inter_b
        pa_inter_b = pa_inter_b / (pa_inter_b.sum(-1)[:, None] + 1e-5)
        type_of_object = (pa_inter_b[:, None, None, :] * self.prob_masking).sum(-1)

        uniq_properties = temporal_consistency[:, :, 3:5]
        uniq_properties = uniq_properties + temporal_consistency[:, :, 3:5].min(-2)[0][:, None, :].abs()
        uniq_properties = (uniq_properties * type_of_object[:, :, 1:]).softmax(-2)

        any_properties = logic_embeddings[:, :, 5:6].sigmoid() * type_of_object[:, :, 2:]
        rebuild = torch.cat((type_of_object, uniq_properties), -1).repeat(logic_embeddings.shape[0], 1, 1)

        # NO CONSTRAINTS (only temporal)
        # rebuild = temporal_consistency.repeat(logic_embeddings.shape[0], 1, 1)
        # any_properties = logic_embeddings[:, :, -1:]
        logic_embeddings = torch.cat((rebuild, any_properties), -1)
        decoder_input = logic_embeddings.view(-1, logic_embeddings.shape[-1])
        decoded_glimpse = self.log_decoder(decoder_input).reshape(*logic_embeddings.shape[0:2],
                                                                  self.inner_filters,
                                                                  *self.glimpse_size)

        for k in range(num_keypoints):
            mask_a = image_a_keypoints['heatmaps'][:, k, :, :].unsqueeze(1)
            mask_b = image_b_keypoints['heatmaps'][:, k, :, :].unsqueeze(1)

            # supress features from image a, around both keypoint locations.
            transported_features = (1 - mask_a) * (1 - mask_b) * transported_features

            if self.apply_post_gauss:
                transported_features[ids[:, None, None], :, y[:, k], x[:, k]] += \
                    decoded_glimpse[:, k].permute(0, 2, 3, 1) * mask_b[ids[:, None, None], :, y[:, k], x[:, k]]
            else:
                transported_features[ids[:, None, None], :, y[:, k], x[:, k]] += \
                    decoded_glimpse[:, k].permute(0, 2, 3, 1)
                #     glimpses[:, k].permute(0, 2, 3, 1)
                #     nondiff_glimpse.permute(0, 2, 3, 1)
                #     diff_glimpse.permute(0, 2, 3, 1)

            masked_mask = mask_b.clone()
            masked_mask[ids[:, None, None], :, y[:, k], x[:, k]] *= 0.0
            transported_features += masked_mask * image_b_features

        return transported_features, logic_embeddings, glimpses, decoded_glimpse


class Encoder(nn.Module):
    '''
    map an image to features,
    CNN with Relu
    '''

    def __init__(
            self,
            initial_height,
            input_channel=3,
            filters=(16, 16, 32, 32),
            kernel_sizes=(7, 3, 3, 3),
            strides=(1, 1, 2, 1),
            norm_type=None
    ):
        super().__init__()
        kernel_size = (kernel_sizes[0], kernel_sizes[0])
        padding = reduce(__add__, [(k // 2 + (k - 2 * (k // 2)) - 1, k // 2) for k in kernel_size[::-1]])
        height = initial_height
        net = []
        net.append(nn.ZeroPad2d(padding))  # TF padding
        net.append(nn.Conv2d(input_channel, filters[0], kernel_sizes[0], strides[0]))
        height = int(height / strides[0])
        add_norm_layer(norm_type, net, filters[0], height)
        net.append(nn.ReLU())
        for i in range(1, len(filters)):
            kernel_size = (kernel_sizes[i], kernel_sizes[i])
            padding = reduce(__add__, [(k // 2 + (k - 2 * (k // 2)) - 1, k // 2) for k in kernel_size[::-1]])
            if strides[i] == 2:
                padding = list(padding)
                padding[1] += padding[0]
                padding[3] += padding[2]
                padding[0] = padding[2] = 0
            net.append(nn.ZeroPad2d(padding))
            net.append(nn.Conv2d(filters[i - 1], filters[i], kernel_sizes[i], strides[i], ))
            height = int(height / strides[i])
            add_norm_layer(norm_type, net, filters[i], height)
            net.append(nn.ReLU())
        self.net = nn.Sequential(*net)

    def forward(self, image):
        '''
        image:[B,C,H,W]
        return: [B,N,F_h,F_w], N=4*filters
        '''
        feature = self.net(image)
        return feature


class Decoder(nn.Module):  # decoder reconstruction network
    def __init__(self, initial_filters, decoder_num_filters, init_height, last_height, output_channels=3,
                 norm_type=None):
        super().__init__()
        self.initial_filters = initial_filters
        self.init_height = init_height
        kernel_size = (3, 3)
        padding = reduce(__add__, [(k // 2 + (k - 2 * (k // 2)) - 1, k // 2) for k in kernel_size[::-1]])

        height = init_height
        net = []
        prev_filters = initial_filters
        filters = decoder_num_filters
        while height <= last_height:
            net.append(nn.ZeroPad2d(padding))
            net.append(nn.Conv2d(prev_filters, filters, 3, 1))
            prev_filters = filters
            add_norm_layer(norm_type, net, filters, height)
            net.append(nn.ReLU())

            if height == last_height:
                net.append(nn.ZeroPad2d(padding))
                net.append(nn.Conv2d(prev_filters, output_channels, 3, 1))
                break
            else:
                net.append(nn.ZeroPad2d(padding))
                net.append(nn.Conv2d(prev_filters, filters, 3, 1))
                prev_filters = filters
                add_norm_layer(norm_type, net, filters, height)
                net.append(nn.ReLU())

            height *= 2
            net.append(Interpolate())

            if filters >= 8:
                filters //= 2

        self.layers = nn.Sequential(*net)

    def forward(self, features):
        '''
        features: [B,N,F_h,F_w]
        '''
        return self.layers(features)


class KeyPointer(nn.Module):  # extract keypoints from an image
    def __init__(self, num_keypoints, keypoint_encoder, gauss_std, initial_filters):
        super().__init__()
        self.num_keypoints = num_keypoints
        self.keypoint_encoder = keypoint_encoder
        self.gauss_std = gauss_std
        self.net = nn.Conv2d(initial_filters, self.num_keypoints, 1, 1)

    def forward(self, image):
        # image [B,C,H,W]
        image_features = self.keypoint_encoder(image)
        keypoint_features = self.net(image_features)
        return self.get_keypoint_data_from_feature_map(keypoint_features, self.gauss_std)

    def get_keypoint_data_from_feature_map(self, feature_map, gauss_std):
        '''
        feature_map:[B,K,H,W]
        centers: [B,K,2]
        heatmaps: [B,K,H,W]
        '''
        gauss_mu = self.get_keypoint_mus(feature_map)
        map_size = feature_map.shape[2:4]
        gauss_maps = self.get_gaussian_maps(gauss_mu, map_size, 1.0 / gauss_std)
        return {
            "centers": gauss_mu,
            "heatmaps": gauss_maps
        }

    def get_keypoint_mus(self, keypoint_features):
        # keypoint_features [B,K,F_h,F_w]
        # gauss_mu: [B,K,2], in [-1,1], first element is y, second is x
        gauss_y = self.get_coord(keypoint_features, 1)
        gauss_x = self.get_coord(keypoint_features, 2)
        gauss_mu = th.stack([gauss_x, gauss_y], dim=2)
        return gauss_mu

    def get_coord(self, features, dim):
        other_dim = 1 if dim == 2 else 2
        dim_size = features.shape[dim + 1]

        # Compute nomalized weight for each row/column along the axis
        g_c_prob = th.mean(features, dim=other_dim + 1, keepdim=False)
        g_c_prob = nn.Softmax(dim=2)(g_c_prob)

        # Linear combination of the interval [-1,1] using the normalized weights to
        # give a single coordinate in the same interval [-1,1]
        scale = th.linspace(-1.0, 1.0, dim_size, device=g_c_prob.device).reshape([1, 1, dim_size])
        coordinate = th.sum(g_c_prob * scale, dim=2, keepdim=False)
        return coordinate

    def get_gaussian_maps(self, mu, map_size, inv_std, power=2):
        # transforms keypoint center to gaussian masks
        mu_x, mu_y = mu[:, :, 0:1], mu[:, :, 1:2]

        y = th.linspace(-1., 1., map_size[0], dtype=torch.float32, device=mu.device)
        x = th.linspace(-1., 1., map_size[1], dtype=torch.float32, device=mu.device)

        mu_y, mu_x = mu_y.unsqueeze(-1), mu_x.unsqueeze(-1)

        y = y.reshape([1, 1, map_size[0], 1])
        x = x.reshape([1, 1, 1, map_size[1]])

        g_y = th.pow(y - mu_y, power)
        g_x = th.pow(x - mu_x, power)
        # dist = (g_y + g_x) * np.power(inv_std, power)
        # g_yx = th.exp(-dist)
        # return g_yx
        # gamma = 0.2
        gamma2 = 0.04
        gamma3 = 0.008
        denom = th.pow((g_y + g_x + gamma2), 1.5)
        return gamma3 / denom


class Interpolate(nn.Module):
    def __init__(self):
        super(Interpolate, self).__init__()
        self.interp = nn.functional.interpolate

    def forward(self, x):
        x = self.interp(x, scale_factor=2., mode='bilinear', align_corners=True, recompute_scale_factor=True)
        return x


class SonnetNorm(nn.Module):
    def __init__(self, axis, shapes):
        super(SonnetNorm, self).__init__()
        self.axis = axis
        self.weight = Parameter(torch.Tensor(*shapes))
        self.bias = Parameter(torch.Tensor(*shapes))
        nn.init.uniform_(self.weight, 0.5, 2)
        nn.init.uniform_(self.bias, -1, 1)

    def forward(self, x):
        mean = x.mean(self.axis, keepdim=True)
        var = x.var(self.axis, keepdim=True, unbiased=True)

        inv = (var + 1e-5).rsqrt()

        # return x * inv + (self.bias - mean * inv)
        return self.weight * (x * inv + (self.bias - mean * inv)) + self.bias


# for debug purpose
class Identity(nn.Module):
    def __init__(self):
        super(Identity, self).__init__()

    def forward(self, x):
        return x
