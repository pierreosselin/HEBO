import glob
import math
import pickle
import time

import numpy as np
import ray.rllib.env.wrappers.atari_wrappers
from joblib import Parallel, delayed
import os.path
import torch
import cv2
from matplotlib import pyplot as plt

from utils.display import plot_keypoints_on_image

CPU = 40
DATABASE = 100000
BATCH_SIZE = 64
# DATABASE = 160 # for debug
REPEAT = 3
DEBUG_POSITIONS = True
DEBUG_POSITIONS = False
# CPU = 1

env_name = "PongNoFrameskip-v4"

if DEBUG_POSITIONS:
    CPU = 1


def downsample(img_batch):
    grey_batch = [cv2.cvtColor(img_batch[i], cv2.COLOR_BGR2GRAY) for i in range(len(img_batch))]
    smaller_grey_batch = [cv2.resize(grey_batch[i], (64, 64), interpolation=cv2.INTER_AREA)
                          for i in range(len(grey_batch))]
    smaller_grey_batch = torch.stack([torch.from_numpy(i) for i in smaller_grey_batch])

    return smaller_grey_batch


def get_object_positions(env):
    # env.unwrapped.ale.setRAM(46, 165)
    ram = env.unwrapped.ale.getRAM()  # get emulator RAM state
    # env.render()
    # time.sleep(1)
    cpu_score = ram[13]  # computer/ai opponent score
    player_score = ram[14]  # your score
    cpu_paddle_y = ram[21]  # Y coordinate of computer paddle
    player_paddle_y = ram[51]  # Y coordinate of your paddle
    ball_x = ram[49]  # X coordinate of ball
    ball_y = ram[54]  # Y coordinate of ball

    positions = np.array([[90, 23], [170, 23], [66, cpu_paddle_y + 5], [ball_x, ball_y], [190, player_paddle_y + 5]])
    positions = positions.astype(np.float32)
    if ball_y == 0:
        positions[3, :] = [None, None]
    if cpu_score >= 10:
        positions[0, 0] -= 8
    if player_score >= 10:
        positions[1, 0] -= 8
    positions[:, 0] -= 48
    positions[:, 1] -= 12
    positions[:, 0] = ((2 * positions[:, 0]) / 160) - 1.
    positions[:, 1] = ((2 * positions[:, 1]) / 210) - 1.
    return positions


if not os.path.isdir(os.path.join('data', env_name, 'pretrained')):
    os.makedirs(os.path.join('data', env_name, 'pretrained'), exist_ok=True)


    def collect(framework, algo, run_id):
        print('starting ', (framework, algo, run_id))

        import random
        import gym
        from utils.wrappers import AtariPreprocessing

        if framework == 'atari_zoo':
            import tensorflow as tf
            from lucid.optvis.render import import_model
            from atari_zoo import MakeAtariModel

            tag = "final"
            m = MakeAtariModel(algo, env_name, run_id, tag)()
        elif framework == 'sb3_zoo':
            from sb3_contrib import ARS, QRDQN, TQC, TRPO
            from stable_baselines3 import A2C, DDPG, DQN, PPO, SAC, TD3

            ALGOS = {
                "a2c": A2C,
                "ddpg": DDPG,
                "dqn": DQN,
                "ppo": PPO,
                "sac": SAC,
                "td3": TD3,
                # SB3 Contrib,
                "ars": ARS,
                "qrdqn": QRDQN,
                "tqc": TQC,
                "trpo": TRPO,
            }
            custom_objects = {
                "learning_rate": 0.0,
                "lr_schedule": lambda _: 0.0,
                "clip_range": lambda _: 0.0,
            }
            model = ALGOS[algo].load("/home/matthieu/git/rl-baselines3-zoo/rl-trained-agents/" +
                                     algo + "/" + env_name + "_1/" + env_name + ".zip",
                                     custom_objects=custom_objects)

        shared_set_s = []
        shared_set_t = []

        shared_set_s_pos = []
        shared_set_t_pos = []

        if DEBUG_POSITIONS:
            firstCall = True
            plt.ion()
            fig, ax = plt.subplots()

        for repeat in range(REPEAT if framework != "atari_zoo" else 1):
            env = gym.make(env_name)
            # noop = 0
            # if "Pong" in env_name:
            #     noop = 60
            # env = AtariPreprocessing(env, noop=noop, frame_skip=4, screen_size=84, grayscale_obs=True)

            env = ray.rllib.env.wrappers.atari_wrappers.NoopResetEnv(env, noop_max=30)
            if env.spec is not None and "NoFrameskip" in env.spec.id:
                env = ray.rllib.env.wrappers.atari_wrappers.MaxAndSkipEnv(env, skip=4)
            env = ray.rllib.env.wrappers.atari_wrappers.EpisodicLifeEnv(env)
            if "FIRE" in env.unwrapped.get_action_meanings():
                env = ray.rllib.env.wrappers.atari_wrappers.FireResetEnv(env)
            env = ray.rllib.env.wrappers.atari_wrappers.WarpFrame(env, 84)
            env = ray.rllib.env.wrappers.atari_wrappers.FrameStack(env, 4)

            if framework == 'atari_zoo':
                tf_graph = tf.Graph()
                with tf_graph.as_default():
                    sess = tf.Session()
                    if algo == "apex":
                        X_t = tf.placeholder(tf.float32, [None] + [env.observation_space.shape[-1]] +
                                             list(env.observation_space.shape[:2]))
                    else:
                        X_t = tf.placeholder(tf.float32, [None] + list(env.observation_space.shape))
                    T = import_model(m, X_t, X_t)
                    action_sample = m.get_action(T)

            obs = env.reset()
            positions = get_object_positions(env)

            all_obs = []
            all_positions = []
            all_rewards = []
            all_actions = []
            all_dones = []
            istate = None

            all_obs.append(obs)
            all_positions.append(positions)

            frame = cv2.resize(
                env.unwrapped.ale.getScreenRGB(),
                (128, 128),
                interpolation=cv2.INTER_AREA,
            )

            step = 0
            np.save(os.path.join('data', env_name, 'pretrained', 'frame128rgb_%s_%s_%s_%s_%s.npy' %
                                 (framework, algo, run_id, repeat, step)), frame)
            np.save(os.path.join('data', env_name, 'pretrained', 'obs84gs_%s_%s_%s_%s_%s.npy' %
                                 (framework, algo, run_id, repeat, step)), obs)

            for step in range(env.spec.max_episode_steps):
                if framework == 'random':
                    action = env.action_space.sample()
                elif framework == 'atari_zoo':
                    if algo == "apex":
                        train_dict = {X_t: np.transpose(obs[None] / 255.0, (0, 3, 1, 2))}
                    else:
                        train_dict = {X_t: obs[None] / 255.0}
                    action = sess.run([action_sample], feed_dict=train_dict)[0][0]
                else:
                    action, istate = model.predict(obs, state=istate, deterministic=False)

                if env_name == "PongNoFrameskip-v4" and np.random.random() < 0.05:
                    action = env.action_space.sample()

                all_actions.append(action)

                obs, reward, done, info = env.step(action)
                positions = get_object_positions(env)
                if DEBUG_POSITIONS:
                    img, _ = plot_keypoints_on_image(obs[:, :, -1], positions)
                    if firstCall:
                        axim = ax.imshow(img)
                        firstCall = False
                    else:
                        axim.set_array(img)
                        fig.canvas.flush_events()
                    time.sleep(0.01)

                all_obs.append(obs)
                all_positions.append(positions)
                all_rewards.append(reward)
                all_dones.append(done)

                frame = cv2.resize(
                    env.unwrapped.ale.getScreenRGB(),
                    (128, 128),
                    interpolation=cv2.INTER_AREA,
                )

                np.save(os.path.join('data', env_name, 'pretrained', 'frame128rgb_%s_%s_%s_%s_%s.npy' %
                                     (framework, algo, run_id, repeat, step + 1)), frame)
                np.save(os.path.join('data', env_name, 'pretrained', 'obs84gs_%s_%s_%s_%s_%s.npy' %
                                     (framework, algo, run_id, repeat, step + 1)), obs)

                if done:
                    break

            np.save(os.path.join('data', env_name, 'pretrained', 'rewards_%s_%s_%s_%s.npy' %
                                 (framework, algo, run_id, repeat)), np.array(all_rewards))
            np.save(os.path.join('data', env_name, 'pretrained', 'dones_%s_%s_%s_%s.npy' %
                                 (framework, algo, run_id, repeat)), np.array(all_dones))
            np.save(os.path.join('data', env_name, 'pretrained', 'actions_%s_%s_%s_%s.npy' %
                                 (framework, algo, run_id, repeat)), np.array(all_actions))
            np.save(os.path.join('data', env_name, 'pretrained', 'actions_%s_%s_%s_%s.npy' %
                                 (framework, algo, run_id, repeat)), np.array(all_positions))

            print("end of episode", np.array(all_rewards).sum())
            if DEBUG_POSITIONS:
                breakpoint()

            mid = len(all_obs) // 2
            source_index = random.randint(0, mid)
            target_index = random.randint(mid, len(all_obs) - 1)
            shared_set_s.append(all_obs[source_index])
            shared_set_s_pos.append(all_positions[source_index])
            shared_set_t.append(all_obs[target_index])
            shared_set_t_pos.append(all_positions[target_index])

        print('done ', (framework, algo, run_id))
        return shared_set_s, shared_set_t, shared_set_s_pos, shared_set_t_pos


    # ['a2c', 'es', 'ga', 'apex', 'rainbow', 'dqn']
    algos = {'atari_zoo': ['a2c', 'es', 'rainbow', 'dqn'], 'sb3_zoo': ["a2c", "dqn", "ppo", "qrdqn"]}
    run_ids = {'atari_zoo': range(1, 4), 'sb3_zoo': range(1)}
    all_configs = [(framework, algo, run_id)
                   for framework in ["sb3_zoo", "atari_zoo"]
                   for algo in algos[framework]
                   for run_id in run_ids[framework]]

    # all_configs = [('atari_zoo', 'dqn', 2)]
    all_configs.append(('random', 'random', 0))

    if CPU == 1:
        shared_set_s, shared_set_t, shared_set_s_pos, shared_set_t_pos = collect(
            *all_configs[np.random.randint(len(all_configs))])
    else:
        results = Parallel(n_jobs=CPU, backend="multiprocessing")(delayed(collect)(*i) for i in all_configs)

        shared_set_s, shared_set_t, shared_set_s_pos, shared_set_t_pos = zip(*results)

if not os.path.isfile(os.path.join('data', env_name, 'pretrained', 'frame_probs.npy')):
    all_paths = []
    all_frames = []
    start = time.time()
    print("loading all the frames in the RAM")
    for step, filefound in enumerate(glob.iglob(os.path.join('data', env_name, 'pretrained') + '/frame128rgb**')):
        all_paths.append(filefound.split('/')[-1])
        all_frames.append(np.load(filefound))
        if step % 10000 == 0:
            print(step, time.time() - start)
        # if step > 1000:  # for debug
        #     break

    start = time.time()
    all_frames = np.array(all_frames)
    unique_images = set()
    unique_images_paths = []
    unique_images_index = []
    print("filtering unique frames over %s frames" % len(all_paths))
    for i in range(all_frames.shape[0]):
        to_hash = pickle.dumps(all_frames[i].flatten())
        if to_hash not in unique_images:
            unique_images.add(to_hash)
            unique_images_index.append(i)
            unique_images_paths.append(all_paths[i])
        if i % 10000 == 0:
            print(i, len(unique_images), time.time() - start)

    unique_images_gpu = downsample(all_frames[unique_images_index]).cuda()

    print("compute image distances")
    D = []
    for i in range(len(unique_images_index)):
        D.append((unique_images_gpu[i, None] - unique_images_gpu[None, :]).float().norm(dim=(-1, -2), p=2)[0].cpu())
        if i % 1000 == 0:
            print(i, time.time() - start)
    D = torch.stack(D)

    # SD = D.softmax(-1)
    # SD.var(-1).mean() 0.0002
    # (SD[0] > 0.01).int().sum(-1).float().mean() 2
    # (SD[0] > 0.0001).int().sum(-1).float().mean() 2

    # SD = D / D.sum(-1)[:, None]
    # SD.var(-1).mean() 9.8563e-10
    # (SD[0] > 0.01).int().sum(-1).float().mean() 0.
    # (SD[0] > 0.0001).int().sum(-1).float().mean() 4945

    # SD = (D * 0.1).softmax(-1)
    # SD.var(-1).mean() 8.0192e-05
    # (SD[0] > 0.01).int().sum(-1).float().mean() 9.
    # (SD[0] > 0.0001).int().sum(-1).float().mean() 48

    SD = (D * 0.05).softmax(-1)
    # SD.var(-1).mean() 2.5643e-05
    # (SD[0] > 0.01).int().sum(-1).float().mean() 19.
    # (SD[0] > 0.0001).int().sum(-1).float().mean() 152

    print(SD.var(-1).mean())
    cut = (SD > 0.01).int().sum(-1).float().mean().cpu().int().numpy()
    print(cut)
    print((SD > 0.0001).int().sum(-1).float().mean())

    smaller_SD = []
    smaller_SD_index = []
    all_paths = np.array(all_paths)[unique_images_index]
    counter = np.zeros(SD.shape[0])
    for i in range(len(unique_images)):
        SD[i][counter > 10] = -torch.inf
        sorted_values, sorted_index = SD[i].sort(descending=True)
        pr = sorted_values[:cut].numpy().astype(np.float64)
        pr = pr / pr.sum()
        smaller_SD.append(pr)
        smaller_SD_index.append(sorted_index[:cut].numpy())
        counter[sorted_index[:cut]] += np.ones(cut)

    np.save(os.path.join('data', env_name, 'pretrained', 'frame_probs.npy'),
            np.array(smaller_SD))
    np.save(os.path.join('data', env_name, 'pretrained', 'frame_probs_index.npy'),
            np.array(smaller_SD_index))
    np.save(os.path.join('data', env_name, 'pretrained', 'frame_index.npy'),
            all_paths)
